package dev.xavier.stein.loader.api;

import java.util.List;

/**
 * Um bloco de informacao na tela que o jogador posiciona na grade do HUD do Stein Loader (Shift direito abre o editor).
 * O Loader guarda o lugar, a escala, se esta ligado e se aparece com o chat aberto, e desenha na hora certa; o mod so diz
 * o tamanho e desenha. Registrar com {@link Hud#register}, no afterStartGame. Tudo na thread do jogo.
 */
public interface HudElement {

    /** Unico entre todos os mods: "&lt;mod&gt;.&lt;nome&gt;". E a chave do lugar salvo. */
    String id();

    /** Nome no editor (ja traduzido). */
    String name();

    /**
     * Monta o conteudo deste quadro e define {@link #width()} e {@link #height()}.
     *
     * @param preview no editor: sem dados de verdade, mostra um exemplo
     * @return false quando nao ha nada a mostrar
     */
    boolean layout(boolean preview, float partialTicks);

    /** Largura do conteudo, em pixels de GUI e sem a escala do jogador. */
    int width();

    /** Altura do conteudo, em pixels de GUI e sem a escala do jogador. */
    int height();

    /**
     * Desenha o conteudo de (0, 0) a ({@link #width}, {@link #height}): o Loader ja transladou e aplicou a escala, e o
     * elemento fica no lugar que o jogador escolheu, seja qual for a borda. <b>Nao desloque o desenho</b> (nada de x
     * negativo quando preso a direita): o que sair da caixa aparece fora do lugar.
     *
     * @param alignRight o elemento esta preso na borda direita: quem tem linhas de largura diferente alinha cada uma
     *     pela direita da caixa ({@code x = width() - larguraDaLinha}), para o texto crescer para dentro da tela
     */
    void draw(boolean alignRight, float partialTicks);

    /** Lugar de fabrica (e o de "Posicao: restaurar" nas opcoes). */
    HudPlacement defaultPlacement();

    /**
     * Lugar da configuracao antiga do proprio mod. O Loader nao o usa mais: elemento novo entra
     * desligado, no lugar de fabrica, e quem liga e o jogador, na lista de elementos do editor.
     */
    default HudPlacement savedPlacement() {
        return null;
    }

    /** Aparece tambem com outras telas abertas (as partes do HUD do proprio jogo). */
    default boolean visibleWithScreens() {
        return false;
    }

    /**
     * Sem efeito para mods: com a tela F3 aberta some tudo que nao e do proprio jogo, sempre. So as partes do jogo na
     * grade (barra de itens, vida, chat...) continuam, como no jogo.
     */
    default boolean hideWithDebug() {
        return true;
    }

    /** Opcoes do elemento, depois das comuns (ativado, com chat, escala, posicao), na tela de opcoes do editor. */
    default void options(List<Option> out) {
    }

    /**
     * Volta as opcoes proprias do elemento (as do {@link #options}) ao padrao. O "Restaurar padrao" do elemento e o da
     * pagina Tela chamam isto depois de devolver lugar e escala; sem ele, restaurar deixava as opcoes como estavam.
     */
    default void restoreOptions() {
    }

    /** Uma opcao mudou (do elemento ou uma das comuns, como ligado): o mod grava a configuracao dele. */
    default void optionsChanged() {
    }
}
