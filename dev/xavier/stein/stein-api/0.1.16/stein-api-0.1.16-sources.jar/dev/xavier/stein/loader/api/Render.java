package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Desenho 2D de HUD e telas, sem o mod falar com OpenGL: retangulos, formas, texto, imagens, itens, cabecas de jogador
 * e texturas feitas pelo mod (um minimapa). O renderer do Stein vai mudar por baixo (o caminho e o Vulkan): quem
 * desenha por aqui continua funcionando, quem chama GL/GlStateManager/Tessellator direto quebra.
 *
 * <p>Coordenadas da GUI (as do {@link HudElement#draw} e do drawScreen), em ponto flutuante: nada pula de pixel em
 * pixel. Cores em ARGB ({@code 0xAARRGGBB}; alfa 0 nao desenha nada — use {@code 0xFF000000 | rgb} para opaco).
 * Chame da thread do jogo, durante o desenho.
 */
@Experimental(since = "0.1.16")
public final class Render {

    private Render() {
    }

    // --- formas ---

    public static void rect(float x, float y, float w, float h, int argb) {
        Host.INSTANCE.drawRect(x, y, w, h, argb);
    }

    /** Retangulo de cantos arredondados (raio r). */
    public static void roundRect(float x, float y, float w, float h, float r, int argb) {
        Host.INSTANCE.drawRoundRect(x, y, w, h, r, argb);
    }

    public static void circle(float cx, float cy, float r, int argb) {
        roundRect(cx - r, cy - r, r * 2, r * 2, r, argb);
    }

    /** Anel de espessura t. */
    public static void ring(float cx, float cy, float r, float t, int argb) {
        Host.INSTANCE.drawRing(cx, cy, r, t, argb);
    }

    /** Triangulo cheio (a seta de um minimapa, um marcador). */
    public static void triangle(float x1, float y1, float x2, float y2, float x3, float y3, int argb) {
        Host.INSTANCE.drawTriangle(x1, y1, x2, y2, x3, y3, argb);
    }

    /**
     * Poligono cheio em leque: o primeiro ponto liga a todos os outros, em ordem (xs[i], ys[i], {@code count}
     * pontos). Um circulo com o numero de lados que voce quiser, uma seta de quatro pontas.
     */
    @Experimental(since = "0.1.16")
    public static void fan(float[] xs, float[] ys, int count, int argb) {
        Host.INSTANCE.drawFan(xs, ys, null, null, count, argb, 0);
    }

    // --- texto ---

    /** Texto com os codigos de cor do jogo; devolve a largura. */
    public static int text(String s, float x, float y, int argb, boolean shadow) {
        return Host.INSTANCE.drawText(s, x, y, argb, shadow);
    }

    public static int textWidth(String s) {
        return Host.INSTANCE.textWidth(s);
    }

    /** A altura de uma linha de texto (9 no jogo). */
    public static int fontHeight() {
        return Host.INSTANCE.fontHeight();
    }

    /** O texto quebrado em linhas de ate {@code width} pixels, levando as cores de uma linha para a outra. */
    @Experimental(since = "0.1.16")
    public static java.util.List<String> wrap(String text, int width) {
        return Host.INSTANCE.wrapText(text, width);
    }

    /** O comeco do texto que cabe em {@code width} pixels (as cores contam como o jogo conta), sem reticencias. */
    @Experimental(since = "0.1.16")
    public static String trim(String text, int width) {
        return Host.INSTANCE.trimText(text, width);
    }

    /** A largura da tela na escala da interface (a mesma do HUD e dos botoes). */
    @Experimental(since = "0.1.16")
    public static int guiWidth() {
        return Host.INSTANCE.guiSize(true);
    }

    /** A altura da tela na escala da interface. */
    @Experimental(since = "0.1.16")
    public static int guiHeight() {
        return Host.INSTANCE.guiSize(false);
    }

    // --- imagens ---

    /**
     * Um pedaco de uma textura dos recursos ("dominio:caminho", ex. {@code "meumod:textures/gui/icone.png"}) em
     * x, y, w, h, das coordenadas u0,v0 a u1,v1 (de 0 a 1), pintado com argb ({@code 0xFFFFFFFF} = as cores dela).
     */
    public static void image(String texture, float x, float y, float w, float h, float u0, float v0, float u1, float v1,
            int argb) {
        Host.INSTANCE.drawImage(texture, x, y, w, h, u0, v0, u1, v1, argb);
    }

    /** A textura inteira. */
    public static void image(String texture, float x, float y, float w, float h) {
        image(texture, x, y, w, h, 0, 0, 1, 1, 0xFFFFFFFF);
    }

    /** O item (ItemStack) como no inventario, 16x16 em x, y; com {@code overlay}, a quantidade e a durabilidade. */
    public static void item(Object stack, int x, int y, boolean overlay) {
        Host.INSTANCE.drawItem(stack, x, y, overlay);
    }

    /**
     * O item com a quantidade que voce escolher: {@code count} null e a da pilha, "" nenhuma, e outro texto vai no
     * canto de baixo como o jogo escreve a quantidade (as flechas de um arco, o total no inventario).
     */
    @Experimental(since = "0.1.16")
    public static void item(Object stack, int x, int y, boolean overlay, String count) {
        Host.INSTANCE.drawItemCount(stack, x, y, overlay, count);
    }

    /**
     * A lista do Tab do proprio jogo, desenhada agora (largura da tela da GUI): para quem guarda o pedido do
     * {@link SteinMod#onPlayerList} e desenha depois, por cima de tudo.
     */
    @Experimental(since = "0.1.16")
    public static void gameTabList(int width) {
        Host.INSTANCE.drawGameTabList(width);
    }

    /** O icone do efeito (id do jogo) como no inventario, 18x18 em x, y; nada se ele nao tem icone. */
    @Experimental(since = "0.1.16")
    public static void effectIcon(int id, float x, float y) {
        Host.INSTANCE.drawEffectIcon(id, x, y);
    }

    /** As barrinhas de ping do Tab do jogo para {@code ms} (10x8 em x, y; negativo = sem conexao). */
    @Experimental(since = "0.1.16")
    public static void pingIcon(int ms, float x, float y) {
        Host.INSTANCE.drawPingIcon(ms, x, y);
    }

    /** O rosto do jogador (com a camada do chapeu), size x size; o padrao do jogo se ele nao esta no Tab. */
    public static void playerHead(String nick, float x, float y, float size) {
        Host.INSTANCE.drawPlayerHead(nick, x, y, size);
    }

    /**
     * O mesmo, e num servidor sem autenticacao (em que todo mundo e Steve) a skin da conta original com esse nick,
     * perguntada a Mojang em lotes e guardada: util para reconhecer quem voce conhece — num servidor offline, o
     * "Notch" de la nao e o Notch. Enquanto a resposta nao chega, a do jogo.
     */
    @Experimental(since = "0.1.16")
    public static void playerHead(String nick, float x, float y, float size, boolean premiumSkin) {
        Host.INSTANCE.drawPlayerHeadPremium(nick, x, y, size, premiumSkin);
    }

    // --- transformacao e recorte ---

    public static void push() {
        Host.INSTANCE.drawPush();
    }

    public static void pop() {
        Host.INSTANCE.drawPop();
    }

    public static void translate(float x, float y) {
        Host.INSTANCE.drawTranslate(x, y);
    }

    public static void scale(float s) {
        Host.INSTANCE.drawScale(s);
    }

    /** Gira em graus, em torno da origem atual. */
    public static void rotate(float degrees) {
        Host.INSTANCE.drawRotate(degrees);
    }

    /** Recorta o desenho ao retangulo (coordenadas da GUI) ate {@link #unclip}. */
    public static void clip(float x, float y, float w, float h) {
        Host.INSTANCE.drawClip(x, y, w, h);
    }

    public static void unclip() {
        Host.INSTANCE.drawUnclip();
    }

    // --- cor ---

    /** A cor com o alfa multiplicado por a (0 a 1). */
    public static int alpha(int argb, float a) {
        int al = Math.round((argb >>> 24) * Math.max(0, Math.min(1, a)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    /** A mistura de duas cores (t = 0: from; 1: to), alfa incluso. */
    public static int mix(int from, int to, float t) {
        float u = Math.max(0, Math.min(1, t));
        int a = Math.round((from >>> 24) + ((to >>> 24) - (from >>> 24)) * u);
        int r = Math.round((from >> 16 & 255) + ((to >> 16 & 255) - (from >> 16 & 255)) * u);
        int g = Math.round((from >> 8 & 255) + ((to >> 8 & 255) - (from >> 8 & 255)) * u);
        int b = Math.round((from & 255) + ((to & 255) - (from & 255)) * u);
        return a << 24 | r << 16 | g << 8 | b;
    }

    // --- texturas do mod ---

    /** Uma textura de w x h pixels feita pelo mod (um minimapa, um grafico), transparente ate o primeiro {@link Texture#set}. */
    public static Texture texture(int w, int h) {
        return new Texture(Host.INSTANCE.textureCreate(w, h), w, h);
    }

    /**
     * Com {@code repeat}, a textura se repete alem das bordas (coordenadas fora de 0 a 1 dao a volta): um mapa em
     * que o bloco (x, z) fica sempre no mesmo pixel, e andar nao exige mover nada.
     */
    @Experimental(since = "0.1.16")
    public static Texture texture(int w, int h, boolean repeat) {
        return new Texture(Host.INSTANCE.textureCreate(w, h, repeat), w, h);
    }

    /** Uma textura do mod. Libere com {@link #release} quando nao precisar mais: ela ocupa memoria de video. */
    public static final class Texture {
        public final int width;
        public final int height;
        private int handle;

        Texture(int handle, int width, int height) {
            this.handle = handle;
            this.width = width;
            this.height = height;
        }

        /** Troca um retangulo de pixels (ARGB, linha a linha, {@code w * h} a partir de {@code offset}). */
        public void set(int x, int y, int w, int h, int[] argb, int offset) {
            if (handle != 0) {
                Host.INSTANCE.textureSet(handle, x, y, w, h, argb, offset);
            }
        }

        /** A textura inteira em x, y, w, h. */
        public void draw(float x, float y, float w, float h) {
            draw(x, y, w, h, 0, 0, 1, 1, 0xFFFFFFFF);
        }

        /** Um pedaco (u0,v0 a u1,v1, de 0 a 1), pintado com argb. */
        public void draw(float x, float y, float w, float h, float u0, float v0, float u1, float v1, int argb) {
            if (handle != 0) {
                Host.INSTANCE.textureDraw(handle, x, y, w, h, u0, v0, u1, v1, argb);
            }
        }

        /**
         * Poligono em leque com a textura (ver {@link Render#fan}): cada ponto (xs, ys) com a sua coordenada de
         * textura (us, vs). Um mapa redondo ou girado.
         */
        @Experimental(since = "0.1.16")
        public void drawFan(float[] xs, float[] ys, float[] us, float[] vs, int count, int argb) {
            if (handle != 0) {
                Host.INSTANCE.drawFan(xs, ys, us, vs, count, argb, handle);
            }
        }

        public void release() {
            if (handle != 0) {
                Host.INSTANCE.textureRelease(handle);
                handle = 0;
            }
        }
    }
}
