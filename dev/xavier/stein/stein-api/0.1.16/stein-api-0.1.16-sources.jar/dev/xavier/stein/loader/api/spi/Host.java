package dev.xavier.stein.loader.api.spi;

import java.util.ServiceLoader;

import dev.xavier.stein.loader.api.HudElement;
import dev.xavier.stein.loader.api.Net;
import dev.xavier.stein.loader.api.Targeting;

/**
 * Quem faz o trabalho por tras da API: o Stein Loader.
 *
 * <p><b>Nao e para mods.</b> Os mods chamam {@code Game}, {@code Keys}, {@code Net}, {@code Hud} e {@code Panel};
 * essas classes repassam para ca. A API assim nao cita nenhuma classe da ponte nem do Loader, e o jar que o
 * desenvolvedor recebe para compilar (stein-api.jar, tools/api-jar.sh) nao diz nada de como o jogo e feito por dentro.
 *
 * <p>Custo: {@link #INSTANCE} e constante ({@code static final}) e so ha uma implementacao, entao o JIT troca a
 * chamada pela do Loader e a inlina — a mesma coisa que chamar o Loader direto.
 */
public interface Host {

    /** A implementacao do Loader, achada por ServiceLoader (META-INF/services/dev.xavier.stein.loader.api.spi.Host). */
    Host INSTANCE = load();

    private static Host load() {
        for (Host h : ServiceLoader.load(Host.class, Host.class.getClassLoader())) {
            return h;
        }
        throw new IllegalStateException("Stein Loader ausente: a API so funciona dentro do jogo");
    }

    // Game

    float partialTicks();

    void setInventoryEffectsHidden(boolean hide);

    void resetCameraSmoothing();

    int enchantmentsVersion();

    Object itemData(Object stack);

    void setItemData(Object stack, Object value);

    void watchBlockModel(Object block, boolean watched);

    Object spriteAt(float u, float v);

    // Keys

    void registerKey(Object binding);

    // Net

    void setProxy(Net.Proxy proxy);

    boolean sendPayload(String channel, byte[] data);

    // Hud

    void registerHud(HudElement element);

    boolean hudEnabled(String id);

    Object hudEditor(Object parent);

    // Panel

    /** Abre o Painel sobre parent; only mostra so a pagina dada, sem a lista das outras. */
    void openPanel(Object parent, String page, boolean only);

    void closePanel();

    // Mods

    boolean modLoaded(String id);

    String modVersion(String id);

    // Inventory (0.1.15)

    int invWindowId();

    boolean invContainerOpen();

    boolean invScreenOpen();

    int invSlotCount();

    Object invSlotStack(int slot);

    int invSlotOf(int inventoryIndex);

    int invIndexOf(int slot);

    Object invStack(int inventoryIndex);

    Object invCursor();

    int invSelected();

    int invFirstEmpty();

    int invArmorPiece(Object stack);

    int invArmorValue(Object stack);

    boolean invClick(int slot, int button, int mode);

    void invSelect(int hotbar);

    void invOpen();

    void invClose();

    int invHovered();

    void invClickLater(String owner, int slot, int button, int mode);

    int invPending(String owner);

    void invClearPending(String owner);

    // Targeting (0.1.15)

    Targeting.Ray raycast(double reach);

    double attackReach();

    Object pointedEntity();

    boolean attack(Object entity);

    void swing();

    boolean interact(Object entity);

    // Entities (0.1.15)

    Object self();

    boolean isLiving(Object entity);

    float health(Object entity);

    float maxHealth(Object entity);

    float absorption(Object entity);

    int armor(Object entity);

    int hurtTime(Object entity);

    // Contexto, log, tarefas (0.1.16)

    java.io.File gameDir();

    /** level 0 info, 1 aviso, 2 erro. */
    void log(String modId, int level, String message, Throwable error);

    void onGameThread(Runnable task);

    void later(int ticks, Runnable task);

    /** O id do mod cuja entrada e esta instancia (ou a classe dela), ou null. */
    String modIdOf(Object modInstance);

    byte[] protect(byte[] plain);

    byte[] unprotect(byte[] stored);

    boolean secretsProtected();

    <T> T readConfig(java.io.File file, Class<T> type, T defaults, String owner);

    void writeJson(java.io.File file, Object value, Class<?> type) throws java.io.IOException;

    java.util.Map<String, String> readStrings(java.io.File file);

    void writeStrings(java.io.File file, java.util.Map<String, String> values) throws java.io.IOException;

    // Players e Relations (0.1.16)

    String selfName();

    java.util.List<String> onlinePlayers();

    String playerTeam(String nick);

    String playerPrefix(String nick);

    String playerSuffix(String nick);

    String playerTabName(String nick);

    int playerPing(String nick);

    /** O nick de uma entidade jogador, ou null. */
    String playerNameOf(Object entity);

    void relationsChanged();

    // Render (0.1.16)

    void drawRect(float x, float y, float w, float h, int argb);

    void drawRoundRect(float x, float y, float w, float h, float r, int argb);

    void drawRing(float cx, float cy, float r, float t, int argb);

    void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3, int argb);

    int drawText(String s, float x, float y, int argb, boolean shadow);

    int textWidth(String s);

    int fontHeight();

    void drawImage(String texture, float x, float y, float w, float h, float u0, float v0, float u1, float v1,
            int argb);

    void drawItem(Object stack, int x, int y, boolean overlay);

    void drawPlayerHead(String nick, float x, float y, float size);

    void drawPush();

    void drawPop();

    void drawTranslate(float x, float y);

    void drawScale(float s);

    void drawRotate(float degrees);

    void drawClip(float x, float y, float w, float h);

    void drawUnclip();

    int textureCreate(int w, int h);

    void textureSet(int handle, int x, int y, int w, int h, int[] argb, int offset);

    void textureDraw(int handle, float x, float y, float w, float h, float u0, float v0, float u1, float v1, int argb);

    void textureRelease(int handle);

    // Account e Server (0.1.16)

    String accountName();

    String accountLauncherName();

    boolean accountIsLauncher();

    int accountKind();

    int accountLauncherKind();

    void accountUseOffline(String nick);

    void accountRestore();

    String serverAddress();

    String serverName();

    String serverLast();

    void serverConnect(String address);

    // Lang (0.1.16)

    String translate(String key, Object[] args);

    boolean hasTranslation(String key);

    String language();

    // Chat (0.1.16)

    void chatPrint(String text);

    void chatActionBar(String text);

    void chatSend(String message);

    Object chatText(String text);

    String chatPlain(Object component);

    String chatFormatted(Object component);

    // Screens (0.1.16)

    Object screenCurrent();

    int screenKind(Object screen);

    int screenWidth(Object screen);

    int screenHeight(Object screen);

    void screenOpen(Object screen);

    Object buttonNew(int id, int x, int y, int width, int height, String label);

    int buttonId(Object button);

    int buttonX(Object button);

    int buttonY(Object button);

    void buttonLabel(Object button, String label);

    void buttonEnabled(Object button, boolean enabled);

    // Keys (0.1.16)

    Object keyBind(String name, int defaultKey, String category);

    Object keyGame(int which);

    int keyCode(Object binding);

    boolean keyIsDown(Object binding);

    boolean keyConsume(Object binding);

    void keyHold(Object binding, boolean held);

    boolean keyPhysical(int key);

    boolean ctrlDown();

    boolean mouseDown(int button);

    int mouseEventButton();

    boolean mouseEventPressed();

    int mouseEventWheel();

    // Entities, Players, Inventory e Server (0.1.16)

    java.util.List<Object> worldPlayers();

    Object playerEntity(String nick);

    boolean isPlayer(Object entity);

    String entityName(Object entity);

    boolean isInvisible(Object entity);

    float distance(Object a, Object b);

    String playerDisplayName(String nick);

    String playerInfoNick(Object playerInfo);

    boolean invAccepts(int slot, Object stack);

    int invRoom(int slot);

    boolean invCrafting(int slot);

    boolean invStacksWith(Object a, Object b);

    String serverConnecting();

    // Stacks, Effects e Terrain (0.1.16)

    Object stackCreate(String id, int count, int damage);

    String stackId(Object stack);

    String stackName(Object stack);

    int stackCount(Object stack);

    int stackMaxCount(Object stack);

    boolean stackDamageable(Object stack);

    int stackDamage(Object stack);

    int stackMaxDamage(Object stack);

    boolean stackSameKind(Object a, Object b);

    java.util.List<dev.xavier.stein.loader.api.Effects.Effect> effectsOf(Object entity);

    String effectName(int id, int amplifier);

    String effectDuration(int ticks, boolean permanent);

    boolean effectHasIcon(int id);

    Object terrainWorld();

    boolean terrainLoaded(int chunkX, int chunkZ);

    int terrainHeight(int x, int z);

    boolean terrainAir(int x, int y, int z);

    boolean terrainSolid(int x, int y, int z);

    boolean terrainWater(int x, int y, int z);

    int terrainColor(int x, int y, int z);

    int terrainMapColor(int x, int y, int z);

    int terrainSkyLight(int x, int y, int z);

    boolean terrainHasSky();

    void terrainSpawners(dev.xavier.stein.loader.api.Terrain.Visitor visitor);

    // Entities, Players, Game e Render do HUD (0.1.16)

    java.util.List<Object> worldEntities();

    int entityKind(Object entity);

    String entityType(Object entity);

    /** axis: 0 x, 1 y, 2 z, 3 yaw. */
    double entityPos(Object entity, int axis, float partialTicks);

    java.util.List<dev.xavier.stein.loader.api.Players.Entry> playerList();

    int playerCount();

    String tabText(boolean header);

    String listScore(String nick);

    int gameFps();

    int gameFpsLimit();

    int gameRefreshRate();

    /** handle 0: leque de uma cor so; senao, com a textura do mod (us, vs). */
    void drawFan(float[] xs, float[] ys, float[] us, float[] vs, int count, int argb, int handle);

    java.util.List<String> wrapText(String text, int width);

    int guiSize(boolean width);

    void drawItemCount(Object stack, int x, int y, boolean overlay, String count);

    void drawEffectIcon(int id, float x, float y);

    void drawPingIcon(int ms, float x, float y);

    void drawPlayerHeadPremium(String nick, float x, float y, float size, boolean premiumSkin);

    int textureCreate(int w, int h, boolean repeat);

    void drawGameTabList(int width);

    // Mira com opcoes e o que o YNYDamageIndicator fazia direto no jogo (0.1.16)

    Targeting.Ray raycastQuery(Targeting.Query query);

    boolean entityAlive(Object entity);

    String entityDisplayName(Object entity);

    Object camera();

    String trimText(String text, int width);

    String terrainBlockId(int x, int y, int z);
}
