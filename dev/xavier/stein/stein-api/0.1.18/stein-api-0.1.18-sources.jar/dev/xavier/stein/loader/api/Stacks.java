package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Pilhas de itens (o ItemStack do jogo, como Object): o que e, quantos, quanto gastou, e criar uma para mostrar. Os ids
 * sao os do comando /give, com ou sem o "minecraft:" ({@code "diamond_sword"}, {@code "minecraft:arrow"}). Pilha null
 * e "nada": da 0, "" ou false.
 *
 * <pre>
 * Object espada = Stacks.create("diamond_sword", 1, 900);   // um exemplo gasto, para o editor do HUD
 * int resta = Stacks.maxDamage(s) - Stacks.damage(s);
 * int flechas = Inventory.count(s -&gt; Stacks.is(s, "arrow"));
 * </pre>
 */
@Experimental(since = "0.1.16")
public final class Stacks {

    private Stacks() {
    }

    /** Uma pilha nova (so para mostrar: nao entra no inventario), ou null se o id nao existe. */
    public static Object create(String id, int count, int damage) {
        return Host.INSTANCE.stackCreate(id, count, damage);
    }

    /** O id do item, com o "minecraft:" ({@code "minecraft:bow"}), ou "". */
    public static String id(Object stack) {
        return Host.INSTANCE.stackId(stack);
    }

    /** E desse item? ({@code Stacks.is(s, "bow")}) */
    public static boolean is(Object stack, String id) {
        if (stack == null || id == null) {
            return false;
        }
        String mine = id(stack);
        return mine.equals(id) || mine.equals("minecraft:" + id);
    }

    /** O nome como o jogo mostra (o dado com bigorna, se tiver), com cores. */
    public static String name(Object stack) {
        return Host.INSTANCE.stackName(stack);
    }

    public static int count(Object stack) {
        return Host.INSTANCE.stackCount(stack);
    }

    /** Quantos cabem numa pilha desse item (64, 16, 1). */
    public static int maxCount(Object stack) {
        return Host.INSTANCE.stackMaxCount(stack);
    }

    /** Gasta com o uso (ferramenta, arma, armadura)? */
    public static boolean isDamageable(Object stack) {
        return Host.INSTANCE.stackDamageable(stack);
    }

    /** O dano: 0 nova; {@link #maxDamage} quebrando. Num item que nao gasta, e o subtipo (a cor da la). */
    public static int damage(Object stack) {
        return Host.INSTANCE.stackDamage(stack);
    }

    public static int maxDamage(Object stack) {
        return Host.INSTANCE.stackMaxDamage(stack);
    }

    /** Os dois sao a mesma coisa para contar (mesmo item e, nos que tem subtipo, o mesmo subtipo)? */
    public static boolean sameKind(Object a, Object b) {
        return Host.INSTANCE.stackSameKind(a, b);
    }
}
