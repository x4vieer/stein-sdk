package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * A conta com que o jogo entra nos servidores. O mod troca e consulta, mas <b>nunca ve o token</b>: a conta do
 * launcher e guardada pelo Loader, a conferencia com a Microsoft e do Loader, e o token nao sai dele (nem para log).
 */
@Experimental(since = "0.1.16")
public final class Account {

    /** O tipo da conta atual. */
    public enum Kind {
        /** Sem conta (nick offline, ou launcher sem conta): so servidor sem autenticacao. */
        OFFLINE,
        /** Conferindo com a Microsoft (a primeira consulta dispara a conferencia, fora da thread do jogo). */
        CHECKING,
        /** Conta Microsoft com o jogo, e e desta sessao. */
        MICROSOFT,
        /** O servico recusou o token: nao e conta Microsoft com o jogo. */
        NOT_MICROSOFT,
        /** Nao deu para conferir (sem internet, servico fora): pergunta de novo depois de 30 s. */
        UNVERIFIED
    }

    private Account() {
    }

    /** O nick da sessao atual. */
    public static String name() {
        return Host.INSTANCE.accountName();
    }

    /** O nick da conta que o launcher entregou. */
    public static String launcherName() {
        return Host.INSTANCE.accountLauncherName();
    }

    /** A sessao atual e a do launcher? */
    public static boolean isLauncher() {
        return Host.INSTANCE.accountIsLauncher();
    }

    /** O tipo da sessao atual; a primeira consulta de cada sessao comeca a conferencia (ver {@link Kind#CHECKING}). */
    public static Kind kind() {
        return Kind.values()[Host.INSTANCE.accountKind()];
    }

    /** O tipo da conta do launcher, mesmo com outra sessao ativa (a lista de contas mostra as duas). */
    public static Kind launcherKind() {
        return Kind.values()[Host.INSTANCE.accountLauncherKind()];
    }

    /** Passa a entrar como o nick, sem conta (o UUID offline que servidor sem autenticacao da ao nick). */
    public static void useOffline(String nick) {
        if (!Players.isValidNick(nick)) {
            throw new IllegalArgumentException("nick invalido: " + nick);
        }
        Host.INSTANCE.accountUseOffline(nick);
    }

    /** Volta para a conta do launcher. */
    public static void restoreLauncher() {
        Host.INSTANCE.accountRestore();
    }
}
