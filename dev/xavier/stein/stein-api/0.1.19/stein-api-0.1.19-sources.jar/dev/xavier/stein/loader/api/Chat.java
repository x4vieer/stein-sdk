package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * O chat e o texto acima da barra de itens. Os textos aceitam os codigos de cor do jogo ({@code §a}, {@code §l}).
 * Chame da thread do jogo.
 *
 * <p>Os componentes de texto do jogo (o que {@link SteinMod#onChat} e {@link SteinMod#onNametag} recebem e devolvem)
 * passam como Object: {@link #text} cria um, {@link #plain} e {@link #formatted} leem.
 */
@Experimental(since = "0.1.16")
public final class Chat {

    private Chat() {
    }

    /** Uma linha no chat, so para o jogador (nao vai ao servidor). Fora do mundo, nada. */
    public static void print(String text) {
        Host.INSTANCE.chatPrint(text);
    }

    /** O texto acima da barra de itens, o mesmo lugar do "Now playing" do disco; some sozinho em alguns segundos. */
    public static void actionBar(String text) {
        Host.INSTANCE.chatActionBar(text);
    }

    /** Manda uma mensagem (ou um comando, com "/") ao servidor, como se o jogador digitasse. Passa por onSendChat. */
    public static void send(String message) {
        Host.INSTANCE.chatSend(message);
    }

    /** Um componente de texto do jogo com esse texto. */
    public static Object text(String text) {
        return Host.INSTANCE.chatText(text);
    }

    /** O texto de um componente, sem os codigos de cor; "" se nao for um componente. */
    public static String plain(Object component) {
        return Host.INSTANCE.chatPlain(component);
    }

    /** O texto de um componente com os codigos de cor; "" se nao for um componente. */
    public static String formatted(Object component) {
        return Host.INSTANCE.chatFormatted(component);
    }
}
