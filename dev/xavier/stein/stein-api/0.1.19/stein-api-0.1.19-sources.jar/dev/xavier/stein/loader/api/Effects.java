package dev.xavier.stein.loader.api;

import java.util.List;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Efeitos de pocao ativos numa entidade (os do proprio jogador; dos outros, o servidor quase nunca manda). O
 * {@link Effect} e da API, nao do jogo: da para criar um para mostrar de exemplo.
 *
 * <pre>
 * for (Effects.Effect e : Effects.of(Entities.self())) {
 *     Render.effectIcon(e.id, x, y);
 *     Render.text(Effects.name(e) + " " + Effects.durationText(e), x + 20, y + 5, 0xFFFFFFFF, true);
 * }
 * </pre>
 */
@Experimental(since = "0.1.16")
public final class Effects {

    /** Um efeito: o id do jogo (1 velocidade, 5 forca, 12 resistencia ao fogo...), o nivel e o tempo que falta. */
    public static final class Effect {
        public final int id;
        /** 0 = nivel I. */
        public final int amplifier;
        /** Ticks que faltam (20 por segundo). */
        public final int duration;
        /** Sem fim (o do farol, ou dado por comando sem tempo): o jogo mostra "**:**". */
        public final boolean permanent;

        public Effect(int id, int amplifier, int duration, boolean permanent) {
            this.id = id;
            this.amplifier = amplifier;
            this.duration = duration;
            this.permanent = permanent;
        }
    }

    private Effects() {
    }

    /** Os efeitos ativos, na ordem do jogo; vazio sem nenhum ou se nao for entidade viva. */
    public static List<Effect> of(Object entity) {
        return Host.INSTANCE.effectsOf(entity);
    }

    /** O nome no idioma do jogo, com o nivel em romano como no inventario ("Velocidade II"). */
    public static String name(Effect e) {
        return Host.INSTANCE.effectName(e.id, e.amplifier);
    }

    /** O tempo que falta como o jogo escreve ("1:30"; "**:**" sem fim). */
    public static String durationText(Effect e) {
        return Host.INSTANCE.effectDuration(e.duration, e.permanent);
    }

    /** Tem icone no inventario? (Alguns, como a vida instantanea, nao tem.) */
    public static boolean hasIcon(int id) {
        return Host.INSTANCE.effectHasIcon(id);
    }
}
