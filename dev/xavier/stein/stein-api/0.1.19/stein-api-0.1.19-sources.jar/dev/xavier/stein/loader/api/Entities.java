package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Vida e estado de entidades, para quem mostra dano, barras de vida ou indicadores. Os valores sao os que o cliente tem:
 * a vida dos outros e a que o servidor sincroniza (ver {@link SteinMod#onHealthChanged}). Entidade que nao e viva
 * (item no chao, flecha) da 0. Chame da thread do jogo.
 */
@Experimental(since = "0.1.15")
public final class Entities {

    private Entities() {
    }

    /** O proprio jogador (EntityPlayerSP), ou null fora do mundo. */
    public static Object self() {
        return Host.INSTANCE.self();
    }

    /** E uma entidade viva (EntityLivingBase: jogador, mob, animal)? */
    public static boolean isLiving(Object entity) {
        return Host.INSTANCE.isLiving(entity);
    }

    /** A vida, em meios coracoes (20 = dez coracoes). */
    public static float health(Object entity) {
        return Host.INSTANCE.health(entity);
    }

    /** A vida maxima. */
    public static float maxHealth(Object entity) {
        return Host.INSTANCE.maxHealth(entity);
    }

    /** A absorcao (os coracoes amarelos). Dos outros, so a de jogadores chega ao cliente. */
    public static float absorption(Object entity) {
        return Host.INSTANCE.absorption(entity);
    }

    /** Os pontos de armadura vestida (0-20), pela armadura que o cliente ve. */
    public static int armor(Object entity) {
        return Host.INSTANCE.armor(entity);
    }

    /** Quanto falta da animacao de dano, em ticks: 10 logo depois do golpe, 0 quando acabou. */
    public static int hurtTime(Object entity) {
        return Host.INSTANCE.hurtTime(entity);
    }

    /** Os jogadores que existem no mundo agora (perto o bastante para o servidor mandar), com voce; vazio fora dele. */
    @Experimental(since = "0.1.16")
    public static java.util.List<Object> players() {
        return Host.INSTANCE.worldPlayers();
    }

    /** O jogador com esse nick no mundo, ou null (esta no Tab mas longe, ou nao esta). */
    @Experimental(since = "0.1.16")
    public static Object player(String nick) {
        return Host.INSTANCE.playerEntity(nick);
    }

    /** E um jogador (EntityPlayer, voce inclusive)? */
    @Experimental(since = "0.1.16")
    public static boolean isPlayer(Object entity) {
        return Host.INSTANCE.isPlayer(entity);
    }

    /** O nick do jogador, ou o nome da entidade ("Zombie", ou o nome dado com etiqueta); null se nao e entidade. */
    @Experimental(since = "0.1.16")
    public static String name(Object entity) {
        return Host.INSTANCE.entityName(entity);
    }

    /** Invisivel (pocao ou comando)? */
    @Experimental(since = "0.1.16")
    public static boolean isInvisible(Object entity) {
        return Host.INSTANCE.isInvisible(entity);
    }

    /** Distancia entre as duas, em blocos; {@link Float#MAX_VALUE} se uma nao for entidade. */
    @Experimental(since = "0.1.16")
    public static float distance(Object a, Object b) {
        return Host.INSTANCE.distance(a, b);
    }

    /** Que entidade e, para um radar. */
    @Experimental(since = "0.1.16")
    public enum Kind {
        PLAYER,
        /** Monstro: zumbi, esqueleto, creeper, aranha, slime, ghast... */
        HOSTILE,
        /** Animal, peixe e lula, morcego, aldeao e golem. */
        PASSIVE,
        /** Item no chao, flecha, carrinho, quadro, e o resto. */
        OTHER
    }

    private static final Kind[] KINDS = Kind.values();

    /** Todas as entidades carregadas no cliente (so leitura, e muda de um tick para o outro). */
    @Experimental(since = "0.1.16")
    public static java.util.List<Object> all() {
        return Host.INSTANCE.worldEntities();
    }

    @Experimental(since = "0.1.16")
    public static Kind kind(Object entity) {
        return KINDS[Host.INSTANCE.entityKind(entity)];
    }

    /** O tipo como o jogo chama ("Zombie", "Villager", "Item"), ou "" para jogador e para o que nao e entidade. */
    @Experimental(since = "0.1.16")
    public static String typeName(Object entity) {
        return Host.INSTANCE.entityType(entity);
    }

    /**
     * A posicao no quadro que esta sendo desenhado: entre a do tick anterior e a de agora, pelo {@code partialTicks}
     * (o que o onOverlay e o HudElement recebem). Com 1, a do ultimo tick.
     */
    @Experimental(since = "0.1.16")
    public static double x(Object entity, float partialTicks) {
        return Host.INSTANCE.entityPos(entity, 0, partialTicks);
    }

    /** Os pes. */
    @Experimental(since = "0.1.16")
    public static double y(Object entity, float partialTicks) {
        return Host.INSTANCE.entityPos(entity, 1, partialTicks);
    }

    @Experimental(since = "0.1.16")
    public static double z(Object entity, float partialTicks) {
        return Host.INSTANCE.entityPos(entity, 2, partialTicks);
    }

    /** Para onde olha, em graus como o jogo conta: 0 = sul, 90 = oeste, 180 = norte (sem limite de voltas). */
    @Experimental(since = "0.1.16")
    public static float yaw(Object entity, float partialTicks) {
        return (float) Host.INSTANCE.entityPos(entity, 3, partialTicks);
    }

    /** Viva de verdade: entidade viva que nao morreu (vida acima de 0 e sem a animacao de morte). */
    @Experimental(since = "0.1.16")
    public static boolean isAlive(Object entity) {
        return Host.INSTANCE.entityAlive(entity);
    }

    /**
     * O nome como o jogo mostra, com as cores (o do time num jogador, o dado com etiqueta num mob). Para o nome sem
     * cor, {@link #name}.
     */
    @Experimental(since = "0.1.16")
    public static String displayName(Object entity) {
        return Host.INSTANCE.entityDisplayName(entity);
    }

    /**
     * De onde a tela e vista: o proprio jogador, ou a entidade que ele assiste no modo espectador. A mira
     * ({@link Targeting}) sai daqui.
     */
    @Experimental(since = "0.1.16")
    public static Object camera() {
        return Host.INSTANCE.camera();
    }
}
