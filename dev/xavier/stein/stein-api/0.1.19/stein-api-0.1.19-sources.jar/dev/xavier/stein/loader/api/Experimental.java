package dev.xavier.stein.loader.api;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Ainda pode mudar numa versao menor do Loader: a forma, o nome ou o momento em que e chamado. O resto da API so muda
 * com aviso, e sem quebrar mod compilado contra ela (tools/ApiCheck.java confere a cada build).
 *
 * <p>Use a vontade, mas conte com ajustar o mod quando o Loader subir.
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.CONSTRUCTOR})
public @interface Experimental {

    /** A versao do Loader em que entrou. */
    String since();
}
