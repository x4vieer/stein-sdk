package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/** O que os mods pedem ao jogo pelo Loader. */
public final class Game {

    private Game() {
    }

    /**
     * Tira a lista de efeitos do inventario (e o deslocamento da tela para o lado) —
     * para quem mostra os efeitos no HUD.
     */
    public static void setInventoryEffectsHidden(boolean hide) {
        Host.INSTANCE.setInventoryEffectsHidden(hide);
    }

    /** Fracao do tick atual, para quem desenha interpolado. */
    public static float partialTicks() {
        return Host.INSTANCE.partialTicks();
    }

    /**
     * Zera os filtros da camera suave do jogo: quem liga a camera suave por um tempo (um
     * zoom, por exemplo) e depois desliga nao deixa sobra do movimento para a proxima vez.
     */
    public static void resetCameraSmoothing() {
        Host.INSTANCE.resetCameraSmoothing();
    }

    /**
     * Versao dos encantamentos: sobe depois de cada gravacao ou remocao da chave "ench" em
     * qualquer NBT. Quem guarda algo tirado dos encantamentos de um ItemStack confere por ela e
     * pelo NBT dele (o mesmo objeto) para saber se ainda vale.
     */
    public static int enchantmentsVersion() {
        return Host.INSTANCE.enchantmentsVersion();
    }

    /**
     * Um lugar em cada ItemStack para o mod guardar o que calculou sobre ele (campo criado pelo
     * patcher): ler e gravar custa um campo, num objeto que o jogo acabou de ler para desenhar
     * — um mapa por identidade custava memoria fora do cache a cada consulta. Um so lugar para
     * todos os mods: confira que o objeto e seu (instanceof) antes de usar, porque outro mod
     * pode ter gravado o dele.
     *
     * @return o objeto guardado (qualquer mod), ou null
     */
    public static Object itemData(Object stack) {
        return Host.INSTANCE.itemData(stack);
    }

    /** Guarda o objeto do mod no ItemStack (ver {@link #itemData}). */
    public static void setItemData(Object stack, Object value) {
        Host.INSTANCE.setItemData(stack, value);
    }

    /**
     * Marca um bloco (Block) para {@link SteinMod#onBlockModel}: so os marcados passam pelos mods
     * na montagem dos chunks, os outros custam a leitura de um campo. Uma marca por bloco, de todos
     * os mods; mudar a marca vale para os chunks montados dali em diante.
     */
    public static void watchBlockModel(Object block, boolean watched) {
        Host.INSTANCE.watchBlockModel(block, watched);
    }

    /**
     * A textura (TextureAtlasSprite) do atlas de blocos e itens que contem a coordenada (u, v) do
     * atlas, ou null — o BakedQuad do 1.8.9 nao guarda a textura, so as coordenadas. Indice refeito
     * a cada recarga de recursos, antes do {@link SteinMod#onModelsReloaded}; pode ser chamado de
     * qualquer thread.
     */
    public static Object spriteAt(float u, float v) {
        return Host.INSTANCE.spriteAt(u, v);
    }

    /** Os quadros por segundo, o numero do F3 (medido a cada segundo). */
    @Experimental(since = "0.1.16")
    public static int fps() {
        return Host.INSTANCE.gameFps();
    }

    /** O limite de quadros escolhido nas opcoes, ou 0 sem limite. */
    @Experimental(since = "0.1.16")
    public static int fpsLimit() {
        return Host.INSTANCE.gameFpsLimit();
    }

    /** A taxa do monitor em Hz (60, 144...), ou 0 se o sistema nao disser. */
    @Experimental(since = "0.1.16")
    public static int refreshRate() {
        return Host.INSTANCE.gameRefreshRate();
    }
}
