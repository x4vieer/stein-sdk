package dev.xavier.stein.loader.api;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.function.Consumer;

/**
 * Download de texto (listas, JSON), fora da thread do jogo e com a volta nela. Segue redirecionamento, desiste em 15 s
 * e se identifica como o Stein Loader. Codigo HTTP fora de 2xx chega como erro.
 */
@Experimental(since = "0.1.16")
public final class Http {

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private Http() {
    }

    /**
     * Baixa o texto de {@code url}. {@code onText} e {@code onError} rodam na thread do jogo.
     *
     * @param onError pode ser null: o erro vai para o log do jogo
     */
    public static void getText(String url, Consumer<String> onText, Consumer<Throwable> onError) {
        Tasks.async(() -> getTextNow(url), onText, onError);
    }

    /** O mesmo, bloqueando: so de dentro de uma tarefa de fundo ({@link Tasks#async}), nunca da thread do jogo. */
    public static String getTextNow(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(15))
                .header("User-Agent", "SteinLoader")
                .GET().build();
        HttpResponse<String> res = CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() / 100 != 2) {
            throw new java.io.IOException("HTTP " + res.statusCode() + " em " + url);
        }
        return res.body();
    }
}
