package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * A grade do HUD do Stein Loader: um editor (Shift direito, em Controles) e um arquivo de lugares
 * (config/steinloader-hud.json) para tudo que os mods mostram na tela, sem um cobrir o outro. As partes do HUD do
 * proprio jogo — action bar, barra do chefe e placar lateral — ja estao nela: o jogador as move, muda o formato ou
 * desliga.
 */
public final class Hud {

    private Hud() {
    }

    /** Poe o elemento na grade (no afterStartGame). O lugar salvo vale; sem ele, o antigo do mod ou o de fabrica. */
    public static void register(HudElement element) {
        Host.INSTANCE.registerHud(element);
    }

    /** O elemento esta ligado (o jogador pode desligar no editor)? Desconhecido: true. */
    public static boolean isEnabled(String id) {
        return Host.INSTANCE.hudEnabled(id);
    }

    /**
     * Uma tela por cima do jogo (a lista do Tab, por exemplo) ocupa esta area, em pixels de GUI, neste quadro: no
     * quadro seguinte a grade esconde os elementos que ficariam embaixo dela. Chame a cada quadro em que ela aparece;
     * sem a chamada, eles voltam.
     */
    @Experimental(since = "0.1.18")
    public static void cover(float x, float y, float w, float h) {
        Host.INSTANCE.hudCover(x, y, w, h);
    }

    /** O editor da grade (GuiScreen), voltando para parent (GuiScreen, ou null para o jogo). */
    public static Object editorScreen(Object parent) {
        return Host.INSTANCE.hudEditor(parent);
    }
}
