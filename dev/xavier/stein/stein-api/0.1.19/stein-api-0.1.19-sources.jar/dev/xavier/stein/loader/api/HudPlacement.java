package dev.xavier.stein.loader.api;

/**
 * Lugar e estado de um elemento na grade do HUD: a borda da tela que ele acompanha, o deslocamento, a escala, se esta
 * ligado e se aparece com o chat aberto. A ancora faz o elemento acompanhar a borda certa quando a janela ou a escala da
 * GUI mudam.
 */
public final class HudPlacement {

    /** 0 esquerda, 1 centro, 2 direita. */
    public final int anchorX;
    /** 0 topo, 1 meio, 2 base. */
    public final int anchorY;
    /** Deslocamento da borda correspondente da caixa (ou do centro) ate a ancora, em pixels de GUI. */
    public final int x;
    public final int y;
    public final float scale;
    /** So para as partes do proprio jogo: elemento de mod entra desligado, e quem liga e o jogador. */
    public final boolean enabled;
    public final boolean showInChat;

    public HudPlacement(int anchorX, int anchorY, int x, int y, float scale, boolean enabled, boolean showInChat) {
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        this.x = x;
        this.y = y;
        this.scale = scale;
        this.enabled = enabled;
        this.showInChat = showInChat;
    }
}
