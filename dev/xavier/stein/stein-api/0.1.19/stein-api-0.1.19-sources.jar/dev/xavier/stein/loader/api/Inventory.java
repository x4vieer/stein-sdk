package dev.xavier.stein.loader.api;

import java.util.function.Predicate;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * O inventario do jogador e a janela aberta: ler, e mexer pelos mesmos cliques de quem joga.
 *
 * <p><b>Dois jeitos de apontar um lugar:</b>
 * <ul>
 *   <li><b>slot</b>: o numero do slot na <b>janela atual</b> — a do bau, da fornalha, ou, sem nenhuma aberta, a do
 *       proprio inventario (janela 0, que existe mesmo com o inventario fechado). E o numero que o jogo usa no clique,
 *       e muda de janela para janela.</li>
 *   <li><b>indice do inventario</b>: a posicao fixa no inventario do jogador, a mesma em qualquer janela: 0-8 a hotbar,
 *       9-35 a bolsa, 36-39 a armadura (36 botas ... 39 capacete). {@link #slotOf} traduz um no outro.</li>
 * </ul>
 *
 * <p><b>Toda acao e um clique de verdade</b> ({@code PlayerControllerMP.windowClick}): o jogo aplica na hora, o
 * servidor recebe o mesmo pacote de um clique humano, e {@link SteinMod#onWindowClick} ve cada um. Funciona com o
 * inventario aberto ou fechado. Nada aqui espera: varias acoes seguidas saem no mesmo tick — o ritmo (e o que o
 * servidor aceita) e decisao do mod, com {@link SteinMod#onTickEnd}. As acoes devolvem false quando nao ha jogador,
 * o slot nao existe na janela atual ou nao havia o que fazer; no modo criativo o inventario do jogo e outro, e os
 * cliques daqui nao valem.
 *
 * <p>Os itens sao ItemStack (null = vazio); chame da thread do jogo.
 */
@Experimental(since = "0.1.15")
public final class Inventory {

    // Modos do clique (o "mode" do windowClick).
    /** Pegar/largar no cursor (botao 0: tudo; 1: metade ao pegar, um ao largar). */
    public static final int PICKUP = 0;
    /** Shift+clique: manda o item para o outro lado da janela (armadura vai para o slot dela). */
    public static final int QUICK_MOVE = 1;
    /** Tecla numerica sobre o slot: troca com a hotbar (o botao e a posicao da hotbar, 0-8). */
    public static final int SWAP = 2;
    /** Botao do meio: copia a pilha cheia (so no criativo). */
    public static final int CLONE = 3;
    /** Tecla de jogar fora sobre o slot (botao 0: um; 1: a pilha). */
    public static final int THROW = 4;
    /** Arrastar distribuindo (os tres passos do arrasto do jogo). */
    public static final int QUICK_CRAFT = 5;
    /** Clique duplo: junta no cursor os itens iguais da janela. */
    public static final int PICKUP_ALL = 6;
    /** "Slot" fora da janela: clicar ali larga o item do cursor no chao. */
    public static final int OUTSIDE = -999;

    // Pecas de armadura (indice do inventario = ARMOR_START + peca).
    public static final int BOOTS = 0;
    public static final int LEGGINGS = 1;
    public static final int CHESTPLATE = 2;
    public static final int HELMET = 3;

    // Indices do inventario do jogador.
    public static final int HOTBAR_START = 0;
    public static final int MAIN_START = 9;
    public static final int ARMOR_START = 36;
    /** Total de indices (0-39). */
    public static final int SIZE = 40;

    private Inventory() {
    }

    // --- janela ---

    /** A janela atual: a do container aberto, ou 0 (o inventario do jogador). -1 sem jogador. */
    public static int windowId() {
        return Host.INSTANCE.invWindowId();
    }

    /** Ha um container do mundo aberto (bau, fornalha, bancada...)? O proprio inventario nao conta. */
    public static boolean isContainerOpen() {
        return Host.INSTANCE.invContainerOpen();
    }

    /** Ha uma tela de inventario na frente (a do jogador ou a de um container)? */
    public static boolean isScreenOpen() {
        return Host.INSTANCE.invScreenOpen();
    }

    /** Quantos slots a janela atual tem (0 sem jogador). */
    public static int slotCount() {
        return Host.INSTANCE.invSlotCount();
    }

    /** O item num slot da janela atual, ou null. */
    public static Object slotStack(int slot) {
        return Host.INSTANCE.invSlotStack(slot);
    }

    /**
     * O slot aceita esse item? E a regra do proprio slot: armadura so a peca certa, fornalha so combustivel embaixo,
     * resultado nada. Slot fora da janela: false.
     */
    @Experimental(since = "0.1.16")
    public static boolean accepts(int slot, Object stack) {
        return Host.INSTANCE.invAccepts(slot, stack);
    }

    /**
     * Quantos itens iguais ao que esta ali ainda cabem no slot — o menor entre o limite do slot e o da pilha. Slot
     * vazio: o limite do slot (64 quase sempre); fora da janela: 0.
     */
    @Experimental(since = "0.1.16")
    public static int room(int slot) {
        return Host.INSTANCE.invRoom(slot);
    }

    /** Slot da criacao (a grade ou o resultado, no inventario ou na bancada)? Item deixado ali cai ao fechar a tela. */
    @Experimental(since = "0.1.16")
    public static boolean isCraftingSlot(int slot) {
        return Host.INSTANCE.invCrafting(slot);
    }

    /** Os dois itens empilham um no outro (mesmo item, mesmo dano, mesmos dados)? Null com null: false. */
    @Experimental(since = "0.1.16")
    public static boolean stacksWith(Object a, Object b) {
        return Host.INSTANCE.invStacksWith(a, b);
    }

    /**
     * Quantos itens do inventario (hotbar e bolsa, 0-35) passam no teste, somando as pilhas:
     * {@code Inventory.count(s -> Stacks.is(s, "arrow"))}.
     */
    @Experimental(since = "0.1.16")
    public static int count(java.util.function.Predicate<Object> which) {
        int n = 0;
        for (int i = 0; i < ARMOR_START; i++) {
            Object s = stack(i);
            if (s != null && which.test(s)) {
                n += Stacks.count(s);
            }
        }
        return n;
    }

    /** O slot da janela atual que mostra esse indice do inventario, ou -1 se ela nao o mostra (a armadura, num bau). */
    public static int slotOf(int inventoryIndex) {
        return Host.INSTANCE.invSlotOf(inventoryIndex);
    }

    /** O indice do inventario do jogador por tras de um slot da janela atual, ou -1 se o slot nao e do jogador. */
    public static int inventoryIndexOf(int slot) {
        return Host.INSTANCE.invIndexOf(slot);
    }

    // --- o inventario do jogador ---

    /** O item num indice do inventario do jogador (0-39), qualquer que seja a janela, ou null. */
    public static Object stack(int inventoryIndex) {
        return Host.INSTANCE.invStack(inventoryIndex);
    }

    /** O item preso no cursor (pego e ainda nao largado), ou null. */
    public static Object cursor() {
        return Host.INSTANCE.invCursor();
    }

    /** A posicao escolhida na hotbar (0-8). */
    public static int selectedHotbar() {
        return Host.INSTANCE.invSelected();
    }

    /** O item na mao, ou null. */
    public static Object heldItem() {
        return stack(selectedHotbar());
    }

    /** A armadura vestida numa peca ({@link #BOOTS}...{@link #HELMET}), ou null. */
    public static Object armor(int piece) {
        return stack(ARMOR_START + piece);
    }

    /**
     * O primeiro indice do inventario, de {@code from} ate {@code to} (inclusive), cujo item passa no teste; -1 se
     * nenhum. Slots vazios nao sao testados.
     */
    public static int find(Predicate<Object> test, int from, int to) {
        for (int i = Math.max(0, from); i <= Math.min(SIZE - 1, to); i++) {
            Object s = stack(i);
            if (s != null && test.test(s)) {
                return i;
            }
        }
        return -1;
    }

    /** O primeiro indice vazio da hotbar e da bolsa (0-35), como o jogo procura; -1 se cheio. */
    public static int firstEmpty() {
        return Host.INSTANCE.invFirstEmpty();
    }

    // --- itens ---

    /** Em que peca esse item se veste ({@link #BOOTS}...{@link #HELMET}), ou -1 se nao e armadura. */
    public static int armorPiece(Object stack) {
        return Host.INSTANCE.invArmorPiece(stack);
    }

    /** Os pontos de armadura do item (a meia-armadura que ele da, sem encantamento), ou 0 se nao e armadura. */
    public static int armorValue(Object stack) {
        return Host.INSTANCE.invArmorValue(stack);
    }

    // --- acoes (cada uma, um ou mais cliques) ---

    /**
     * Um clique cru na janela atual, como o jogo faz.
     *
     * @param slot o slot, ou {@link #OUTSIDE}
     * @param button o botao (ou a posicao da hotbar, no {@link #SWAP})
     * @param mode {@link #PICKUP}, {@link #QUICK_MOVE}...
     * @return false se nao havia jogador ou o slot nao existe na janela
     */
    public static boolean click(int slot, int button, int mode) {
        return Host.INSTANCE.invClick(slot, button, mode);
    }

    /** Pega o item do slot (ou larga o do cursor nele): um clique esquerdo. */
    public static boolean pickup(int slot) {
        return click(slot, 0, PICKUP);
    }

    /** Clique direito: pega metade da pilha, ou larga um item do cursor. */
    public static boolean pickupHalf(int slot) {
        return click(slot, 1, PICKUP);
    }

    /** Shift+clique no slot. */
    public static boolean quickMove(int slot) {
        return click(slot, 0, QUICK_MOVE);
    }

    /** Troca o slot com uma posicao da hotbar (0-8), como a tecla numerica sobre ele. */
    public static boolean swapHotbar(int slot, int hotbar) {
        return click(slot, hotbar, SWAP);
    }

    /** Joga no chao um item do slot, ou a pilha inteira. */
    public static boolean drop(int slot, boolean wholeStack) {
        return click(slot, wholeStack ? 1 : 0, THROW);
    }

    /** Larga no chao o que esta no cursor. */
    public static boolean dropCursor() {
        return cursor() != null && click(OUTSIDE, 0, PICKUP);
    }

    /**
     * Leva o item de um slot para outro da janela atual: pega, larga no destino e, se sobrou algo no cursor (o destino
     * estava ocupado com outro item, ou a pilha nao coube), devolve para a origem — ocupado vira troca. Dois ou tres
     * cliques. So comeca com o cursor vazio.
     */
    public static boolean move(int from, int to) {
        if (from == to || cursor() != null || slotStack(from) == null) {
            return false;
        }
        if (!pickup(from) || !pickup(to)) {
            return false;
        }
        return cursor() == null || pickup(from);
    }

    /**
     * Veste a armadura que esta num indice do inventario, no slot da peca dela. Com o slot vazio, um shift+clique;
     * ocupado, troca (a velha vai para onde estava a nova). So com a armadura a vista na janela atual — o inventario do
     * jogador, aberto ou fechado; num bau, false.
     */
    public static boolean equip(int inventoryIndex) {
        int piece = armorPiece(stack(inventoryIndex));
        if (piece < 0 || inventoryIndex == ARMOR_START + piece) {
            return false;
        }
        int from = slotOf(inventoryIndex);
        int to = slotOf(ARMOR_START + piece);
        if (from < 0 || to < 0) {
            return false;
        }
        return armor(piece) == null ? quickMove(from) : move(from, to);
    }

    /** Tira a armadura de uma peca para a bolsa ou a hotbar (shift+clique). False se nao ha armadura ou lugar. */
    public static boolean unequip(int piece) {
        int slot = slotOf(ARMOR_START + piece);
        if (armor(piece) == null || slot < 0 || firstEmpty() < 0) {
            return false;
        }
        return quickMove(slot);
    }

    /**
     * Comeca a usar o item da mao (comer, beber, levantar a espada, puxar o arco), como o clique direito no ar — com
     * qualquer tela aberta ou sem nenhuma. O jogo so continua usando enquanto a tecla de usar estiver apertada (sem
     * tela aberta): quem usa segura {@code Keys.game(GameKey.USE).hold(true)} ate acabar, e solta no fim.
     *
     * @return false sem jogador ou sem item na mao
     */
    @Experimental(since = "0.1.19")
    public static boolean useHeldItem() {
        return Host.INSTANCE.invUseHeld();
    }

    /** O jogador esta usando um item agora (comendo, bebendo, defendendo, puxando o arco)? */
    @Experimental(since = "0.1.19")
    public static boolean isUsingItem() {
        return Host.INSTANCE.invUsing();
    }

    /**
     * Escolhe a posicao da hotbar (0-8), como a roda do mouse ou a tecla numerica. O servidor fica sabendo no proximo
     * tick, como no jogo.
     */
    public static void selectHotbar(int hotbar) {
        Host.INSTANCE.invSelect(hotbar);
    }

    /**
     * O slot da janela atual sob o mouse (com uma tela de inventario ou container aberta), ou -1 — o que o jogo destaca
     * com o quadrado claro.
     */
    @Experimental(since = "0.1.16")
    public static int hoveredSlot() {
        return Host.INSTANCE.invHovered();
    }

    /**
     * Poe um clique na fila do Loader: sai um por tick, na ordem, pelo mesmo caminho de {@link #click}. Para mexer em
     * muitos slots sem mandar tudo no mesmo tick (servidor que conta cliques). A fila e da janela em que o clique foi
     * pedido: se outra janela abrir (ou a tela fechar e a janela mudar), o que sobrou e descartado — um slot de bau
     * nunca cai noutra janela.
     */
    @Experimental(since = "0.1.16")
    public static void clickLater(int slot, int button, int mode) {
        clickLater("", slot, button, mode);
    }

    /**
     * O mesmo, na fila do dono (em geral o id do mod): cada mod conta e descarta so os seus cliques. Os donos revezam,
     * um clique por tick no total. Pedido com uma tela de inventario aberta, o clique tambem cai se ela fechar.
     */
    @Experimental(since = "0.1.16")
    public static void clickLater(String owner, int slot, int button, int mode) {
        Host.INSTANCE.invClickLater(owner, slot, button, mode);
    }

    /** Quantos cliques ainda estao na fila ({@link #clickLater}). */
    @Experimental(since = "0.1.16")
    public static int pendingClicks() {
        return pendingClicks("");
    }

    /** Quantos cliques do dono ainda estao na fila. */
    @Experimental(since = "0.1.16")
    public static int pendingClicks(String owner) {
        return Host.INSTANCE.invPending(owner);
    }

    /** Descarta a fila de cliques. */
    @Experimental(since = "0.1.16")
    public static void clearPending() {
        clearPending("");
    }

    /** Descarta os cliques do dono que ainda estao na fila. */
    @Experimental(since = "0.1.16")
    public static void clearPending(String owner) {
        Host.INSTANCE.invClearPending(owner);
    }

    /**
     * Esconde a tela do container aberto <b>sem fecha-lo</b>: o servidor continua com o bau aberto (os cliques nele
     * valem, pelos slots da janela) e o jogador volta a jogar, sem ver a tela. Chame no mesmo tick em que o container
     * abriu (o fim do tick vem antes do desenho, entao a tela nem aparece). Feche depois com {@link #closeContainer}.
     */
    @Experimental(since = "0.1.19")
    public static void hideContainerScreen() {
        Host.INSTANCE.invHideScreen();
    }

    /**
     * O proximo bau que o servidor abrir (nos proximos {@code millis}) vira um <b>container virtual</b>: aberto de
     * verdade (os cliques nele valem, e {@link #isContainerOpen} diz que sim), mas sem tela nenhuma — o jogador nao ve
     * nada, nem um quadro, e o mouse continua preso no jogo. Feche com {@link #closeContainer}. 0 desarma.
     */
    @Experimental(since = "0.1.19")
    public static void openVirtualNext(long millis) {
        Host.INSTANCE.invVirtualNext(millis);
    }

    /** Fecha o container aberto, com ou sem a tela dele a vista (avisa o servidor, como o Esc). */
    @Experimental(since = "0.1.19")
    public static void closeContainer() {
        Host.INSTANCE.invCloseContainer();
    }

    /**
     * Avisa o servidor que a janela {@code windowId} fechou, sem mexer na tela do cliente: para um container escondido
     * ({@link #hideContainerScreen}) que perdeu o lugar para outra tela (o jogador abriu o inventario por cima).
     */
    @Experimental(since = "0.1.19")
    public static void closeWindowOnServer(int windowId) {
        Host.INSTANCE.invCloseWindow(windowId);
    }

    /** Quantos slots o container aberto tem, sem contar o inventario do jogador (0 sem container). */
    @Experimental(since = "0.1.19")
    public static int containerSize() {
        return isContainerOpen() ? Math.max(0, slotCount() - 36) : 0;
    }

    /** Abre a tela do inventario do jogador, como a tecla E. */
    public static void openInventory() {
        Host.INSTANCE.invOpen();
    }

    /** Fecha a tela de inventario ou de container aberta, avisando o servidor, como o Esc. */
    public static void closeScreen() {
        Host.INSTANCE.invClose();
    }
}
