package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Teclas: as do mod na tela de Controles, as do jogo, e o teclado e o mouse como estao agora.
 *
 * <pre>
 * private Keys.Binding marcar;
 * public void afterStartGame() {
 *     marcar = Keys.bind("key.meumod.marcar", Keys.KEY_M, "key.categories.meumod");
 * }
 * public void onKeyInput() {
 *     while (marcar.consumeClick()) { ... }
 * }
 * </pre>
 *
 * <p>Por que passar por aqui, e nao pela lista do jogo: o jogo le o options.txt
 * dentro do startGame, antes de os mods registrarem as teclas deles (afterStartGame), entao a tecla precisa entrar
 * na lista das opcoes e receber o codigo ja salvo — senao o proximo saveOptions gravaria o padrao por cima da
 * escolha do jogador.
 *
 * <p>Os codigos de tecla sao os do LWJGL 2, que o jogo grava no options.txt ({@link #KEY_NONE} = sem tecla). Botao
 * de mouse numa tecla vale {@code botao - 100} (o botao do meio e -98).
 */
public final class Keys {

    /** Sem tecla. */
    public static final int KEY_NONE = 0;
    public static final int KEY_ESCAPE = 1;
    public static final int KEY_TAB = 15;
    public static final int KEY_Q = 16;
    public static final int KEY_E = 18;
    public static final int KEY_R = 19;
    public static final int KEY_T = 20;
    public static final int KEY_Y = 21;
    public static final int KEY_U = 22;
    public static final int KEY_I = 23;
    public static final int KEY_O = 24;
    public static final int KEY_P = 25;
    public static final int KEY_RETURN = 28;
    public static final int KEY_LCONTROL = 29;
    public static final int KEY_F = 33;
    public static final int KEY_G = 34;
    public static final int KEY_H = 35;
    public static final int KEY_J = 36;
    public static final int KEY_K = 37;
    public static final int KEY_L = 38;
    public static final int KEY_LSHIFT = 42;
    public static final int KEY_Z = 44;
    public static final int KEY_X = 45;
    public static final int KEY_C = 46;
    public static final int KEY_V = 47;
    public static final int KEY_B = 48;
    public static final int KEY_N = 49;
    public static final int KEY_M = 50;
    public static final int KEY_RSHIFT = 54;
    public static final int KEY_LMENU = 56;
    public static final int KEY_SPACE = 57;
    public static final int KEY_F1 = 59;
    public static final int KEY_RCONTROL = 157;
    public static final int KEY_RMENU = 184;
    public static final int KEY_INSERT = 210;

    /** Teclas do jogo (as da tela de Controles do proprio Minecraft). */
    @Experimental(since = "0.1.16")
    public enum GameKey {
        FORWARD, BACK, LEFT, RIGHT, JUMP, SNEAK, SPRINT, ATTACK, USE, PICK_BLOCK, DROP, INVENTORY, CHAT, COMMAND,
        PLAYER_LIST, PERSPECTIVE, SCREENSHOT
    }

    /** Uma tecla da tela de Controles: do mod ({@link #bind}) ou do jogo ({@link #game}). */
    @Experimental(since = "0.1.16")
    public static final class Binding {

        private final Object handle;

        private Binding(Object handle) {
            this.handle = handle;
        }

        /** A tecla que o jogador escolheu (ver os codigos em {@link Keys}). */
        public int key() {
            return Host.INSTANCE.keyCode(handle);
        }

        /**
         * Troca a tecla (0 = nenhuma), como a tela de Controles faz: vale na hora e fica gravada no options.txt. E o
         * que um {@link Option#key} no Painel chama.
         */
        @Experimental(since = "0.1.19")
        public void setKey(int key) {
            Host.INSTANCE.keySet(handle, key);
        }

        /** Apertada agora? */
        public boolean isDown() {
            return Host.INSTANCE.keyIsDown(handle);
        }

        /**
         * Um aperto que ainda nao foi visto: true uma vez por aperto (o jogo conta os apertos entre um tick e outro).
         * Leia com while no onKeyInput ou no onTickEnd.
         */
        public boolean consumeClick() {
            return Host.INSTANCE.keyConsume(handle);
        }

        /**
         * Segura a tecla como se o dedo estivesse nela (true), ou devolve ao que o teclado diz (false). E como um
         * "correr sempre": {@code Keys.game(GameKey.SPRINT).hold(true)}.
         */
        public void hold(boolean held) {
            Host.INSTANCE.keyHold(handle, held);
        }

        /** O KeyBinding do jogo, para quem precisa dele. */
        public Object handle() {
            return handle;
        }
    }

    private static final Binding[] GAME = new Binding[GameKey.values().length];

    private Keys() {
    }

    /** Registra uma KeyBinding (tipo do jogo, como Object) depois do startGame. */
    public static void register(Object binding) {
        Host.INSTANCE.registerKey(binding);
    }

    /**
     * Uma tecla nova na tela de Controles. {@code name} e {@code category} sao chaves do .lang do mod
     * ("key.meumod.marcar", "key.categories.meumod"). Chame no afterStartGame, uma vez por tecla.
     */
    @Experimental(since = "0.1.16")
    public static Binding bind(String name, int defaultKey, String category) {
        return new Binding(Host.INSTANCE.keyBind(name, defaultKey, category));
    }

    /** Uma tecla do jogo. */
    @Experimental(since = "0.1.16")
    public static Binding game(GameKey key) {
        Binding b = GAME[key.ordinal()];
        if (b == null) {
            b = new Binding(Host.INSTANCE.keyGame(key.ordinal()));
            GAME[key.ordinal()] = b;
        }
        return b;
    }

    /** A tecla (codigo do teclado; negativo = botao do mouse, como em {@link #key}) esta apertada agora? */
    @Experimental(since = "0.1.16")
    public static boolean isDown(int key) {
        return Host.INSTANCE.keyPhysical(key);
    }

    /** Um dos Shift apertado (o mesmo teste do shift+clique do jogo). */
    @Experimental(since = "0.1.16")
    public static boolean isShiftDown() {
        return isDown(KEY_LSHIFT) || isDown(KEY_RSHIFT);
    }

    /** Um dos Ctrl apertado (no macOS, tambem o Command, como o jogo faz). */
    @Experimental(since = "0.1.16")
    public static boolean isCtrlDown() {
        return Host.INSTANCE.ctrlDown();
    }

    /** Um dos Alt apertado. */
    @Experimental(since = "0.1.16")
    public static boolean isAltDown() {
        return isDown(KEY_LMENU) || isDown(KEY_RMENU);
    }

    /** O botao do mouse (0 esquerdo, 1 direito, 2 meio) esta apertado agora? */
    @Experimental(since = "0.1.16")
    public static boolean isMouseDown(int button) {
        return Host.INSTANCE.mouseDown(button);
    }

    /**
     * O botao do evento de mouse em andamento, ou -1 (movimento ou roda). So vale dentro do
     * {@link SteinMod#onMouseInput} e do {@link SteinMod#onGuiMouseInput}.
     */
    @Experimental(since = "0.1.16")
    public static int mouseButton() {
        return Host.INSTANCE.mouseEventButton();
    }

    /** O botao do evento em andamento foi apertado (true) ou solto (false)? Ver {@link #mouseButton}. */
    @Experimental(since = "0.1.16")
    public static boolean mousePressed() {
        return Host.INSTANCE.mouseEventPressed();
    }

    /** A roda no evento em andamento: positivo para cima, negativo para baixo, 0 sem roda. */
    @Experimental(since = "0.1.16")
    public static int mouseWheel() {
        return Host.INSTANCE.mouseEventWheel();
    }
}
