package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Traducao: as chaves dos arquivos {@code assets/<id>/lang/<lingua>.lang} que o mod traz no jar, na lingua que o
 * jogador escolheu. Chave que falta na lingua dele cai no {@code en_US}; que falta nos dois volta como a propria chave.
 *
 * <pre>
 * Lang.tr("meumod.titulo")                 // "Meu Mod"
 * Lang.tr("meumod.segundos", 5)            // meumod.segundos=%s segundos  -> "5 segundos"
 * </pre>
 *
 * <p>Os argumentos seguem o {@link String#format} ({@code %s}, {@code %d}, {@code %1$s}). Mais curto dentro do mod:
 * {@link ModContext#tr}.
 */
@Experimental(since = "0.1.16")
public final class Lang {

    private static final Object[] NONE = new Object[0];

    private Lang() {
    }

    /** O texto da chave, sem argumentos. */
    public static String tr(String key) {
        return Host.INSTANCE.translate(key, NONE);
    }

    /** O texto da chave com os argumentos no lugar dos {@code %s}. */
    public static String tr(String key, Object... args) {
        return Host.INSTANCE.translate(key, args);
    }

    /** Se a chave existe na lingua do jogador ou em ingles: para achar chave esquecida no .lang. */
    public static boolean has(String key) {
        return Host.INSTANCE.hasTranslation(key);
    }

    /** O codigo da lingua escolhida, como o jogo escreve: {@code en_US}, {@code pt_BR}. */
    public static String language() {
        return Host.INSTANCE.language();
    }
}
