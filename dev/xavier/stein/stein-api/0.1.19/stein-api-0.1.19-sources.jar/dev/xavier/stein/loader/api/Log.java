package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Log de um mod, com o id dele na frente: {@code [meumod] mensagem}. Vai para o log do jogo (logs/latest.log) e, com o
 * registro do Stein ligado, para ele tambem.
 *
 * <p>{@link #debug} so escreve com a depuracao do mod ligada: {@code -Dstein.debug=meumod} (ou {@code =all}, ou uma
 * lista separada por virgula) na linha de comando do jogo.
 */
@Experimental(since = "0.1.16")
public final class Log {

    private final String id;
    private final boolean debug;

    private Log(String id) {
        this.id = id;
        String on = System.getProperty("stein.debug", "");
        boolean d = false;
        for (String s : on.split(",")) {
            d |= s.trim().equals(id) || s.trim().equals("all");
        }
        this.debug = d;
    }

    /** O log do mod com esse id. */
    public static Log of(String modId) {
        return new Log(modId);
    }

    public void info(String message) {
        Host.INSTANCE.log(id, 0, message, null);
    }

    public void warn(String message) {
        Host.INSTANCE.log(id, 1, message, null);
    }

    public void error(String message, Throwable error) {
        Host.INSTANCE.log(id, 2, message, error);
    }

    /** So com a depuracao do mod ligada (ver a classe). */
    public void debug(String message) {
        if (debug) {
            Host.INSTANCE.log(id, 0, "(debug) " + message, null);
        }
    }

    public boolean isDebug() {
        return debug;
    }
}
