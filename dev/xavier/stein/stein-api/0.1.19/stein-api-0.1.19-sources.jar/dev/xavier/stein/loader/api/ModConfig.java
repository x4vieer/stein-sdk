package dev.xavier.stein.loader.api;

import java.io.File;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * As configuracoes de um mod num arquivo JSON, {@code config/<arquivo>.json} na pasta do jogo — o carregar e salvar
 * que cada mod escrevia a mao.
 *
 * <p>O tipo e uma classe simples com campos e um construtor sem argumentos, que da os padroes:
 * <pre>
 * static final class Config { boolean enabled = true; String color = "c"; int distance = 16; }
 * static final ModConfig&lt;Config&gt; CONFIG = ModConfig.of("meumod", Config.class);
 * ... CONFIG.get().enabled ...  CONFIG.saveSoon();
 * </pre>
 *
 * <ul>
 *   <li><b>Carrega campo a campo</b>: o que falta no arquivo fica no padrao, e um valor que nao se le (tipo errado,
 *       lixo) volta ao padrao so naquele campo — o resto do arquivo vale. Arquivo que nao e JSON e guardado ao lado
 *       ({@code .bad}) e o mod comeca dos padroes.</li>
 *   <li><b>Salva sem corromper</b>: escreve num arquivo temporario e troca de uma vez; cair no meio nao deixa um JSON
 *       pela metade.</li>
 *   <li>{@link #saveSoon} junta varias mudancas (cada tecla de um campo de texto) num salvamento so, um segundo
 *       depois.</li>
 * </ul>
 */
@Experimental(since = "0.1.16")
public final class ModConfig<T> {

    private final String name;
    private final Class<T> type;
    private final Log log;
    private T value;
    private boolean pending;

    private ModConfig(String name, Class<T> type) {
        this.name = name;
        this.type = type;
        this.log = Log.of(name);
        this.value = load();
    }

    /** {@code config/<name>.json}; ja carregado. */
    public static <T> ModConfig<T> of(String name, Class<T> type) {
        return new ModConfig<>(name, type);
    }

    /** O arquivo. */
    public File file() {
        return new File(Host.INSTANCE.gameDir(), "config/" + name + ".json");
    }

    /** Os valores atuais (o mesmo objeto ate um {@link #reset} ou {@link #reload}). */
    public T get() {
        return value;
    }

    /** Volta tudo aos padroes e salva. */
    public T reset() {
        value = defaults();
        save();
        return value;
    }

    /** Le o arquivo de novo. */
    public T reload() {
        value = load();
        return value;
    }

    /** Salva agora. */
    public void save() {
        pending = false;
        try {
            Host.INSTANCE.writeJson(file(), value, type);
        } catch (Exception e) {
            log.error("nao consegui salvar " + file(), e);
        }
    }

    /** Salva daqui a um segundo, juntando as mudancas desse meio tempo num salvamento so. */
    public void saveSoon() {
        if (pending) {
            return;
        }
        pending = true;
        Tasks.later(20, () -> {
            if (pending) {
                save();
            }
        });
    }

    private T defaults() {
        try {
            var c = type.getDeclaredConstructor();
            c.setAccessible(true);
            return c.newInstance();
        } catch (ReflectiveOperationException e) {
            throw new IllegalArgumentException(type + " precisa de um construtor sem argumentos", e);
        }
    }

    private T load() {
        return Host.INSTANCE.readConfig(file(), type, defaults(), name);
    }
}
