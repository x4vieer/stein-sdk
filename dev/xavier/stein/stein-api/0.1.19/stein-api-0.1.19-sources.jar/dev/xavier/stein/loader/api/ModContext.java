package dev.xavier.stein.loader.api;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * O que o Loader da a cada mod — o que o {@code JavaPlugin} da a um plugin de Spigot: id, versao, log, pasta e
 * configuracao, sem o mod montar caminho de arquivo nem prefixo de log.
 *
 * <pre>
 * public final class MeuMod implements SteinMod {
 *     private final ModContext ctx = ModContext.of(this);
 *     private final ModConfig&lt;Config&gt; config = ctx.config(Config.class);
 *     ... ctx.log().info("pronto"); ...
 * }
 * </pre>
 */
@Experimental(since = "0.1.16")
public final class ModContext {

    private final String id;
    private final Log log;
    private final Map<Class<?>, ModConfig<?>> configs = new HashMap<>();

    private ModContext(String id) {
        this.id = id;
        this.log = Log.of(id);
    }

    /**
     * O contexto do mod dono desta instancia (a classe de entrada, a do {@code entry} do steinmod.json). Pode ser
     * chamado no construtor, num campo.
     */
    public static ModContext of(SteinMod mod) {
        String id = Host.INSTANCE.modIdOf(mod);
        if (id == null) {
            throw new IllegalArgumentException(mod.getClass().getName() + " nao e a entrada de um mod carregado");
        }
        return new ModContext(id);
    }

    public String id() {
        return id;
    }

    public String version() {
        return Host.INSTANCE.modVersion(id);
    }

    public Log log() {
        return log;
    }

    /**
     * {@code config/<id>.json}, o arquivo de {@link #config}: para o mod que ja tem o seu leitor de configuracao e so
     * precisa do lugar certo.
     */
    public File configFile() {
        return new File(Host.INSTANCE.gameDir(), "config/" + id + ".json");
    }

    /** {@code config/<id>/}, criada na primeira chamada: para o que nao cabe no JSON de configuracao. */
    public File folder() {
        File f = new File(Host.INSTANCE.gameDir(), "config/" + id);
        f.mkdirs();
        return f;
    }

    /** A configuracao do mod em {@code config/<id>.json} (ver {@link ModConfig}); uma por tipo. */
    @SuppressWarnings("unchecked")
    public <T> ModConfig<T> config(Class<T> type) {
        return (ModConfig<T>) configs.computeIfAbsent(type, t -> ModConfig.of(id, type));
    }

    /** O texto da chave na lingua do jogador (ver {@link Lang}). */
    public String tr(String key, Object... args) {
        return Lang.tr(key, args);
    }

    /** Guardado no cofre do sistema, por mod (ver {@link Secrets}). */
    public Secrets secrets() {
        return Secrets.of(id);
    }
}
