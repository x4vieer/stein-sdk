package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Os outros mods: quem esta carregado, e em que versao.
 *
 * <p>Para usar outro mod, declare no steinmod.json — {@code "depends": {"id": "versao"}} se o seu nao funciona sem
 * ele, {@code "optional"} se funciona. O Loader so sobe o seu com o que ele pede ligado, e na versao pedida, e sobe o
 * pedido antes. Os mods dividem o mesmo class loader: com o outro compilado junto (no classpath do seu build), o seu
 * chama as classes dele direto. Com {@code optional}, confira {@link #isLoaded} antes de tocar em qualquer classe
 * dele — a classe so e procurada quando o codigo que a usa roda.
 */
public final class Mods {

    private Mods() {
    }

    /** O mod com este id (o "id" do steinmod.json) subiu e esta rodando. */
    public static boolean isLoaded(String id) {
        return Host.INSTANCE.modLoaded(id);
    }

    /** A versao do mod carregado com este id, ou null se ele nao esta carregado. */
    public static String version(String id) {
        return Host.INSTANCE.modVersion(id);
    }
}
