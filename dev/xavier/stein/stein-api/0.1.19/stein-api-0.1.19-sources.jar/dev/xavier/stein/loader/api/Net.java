package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Por onde a conexao com o servidor sai — para um mod que saiba falar com proxy. O Loader nao implementa nada:
 * so entrega ao mod os dois pontos que a ponte abre no caminho de conexao do jogo.
 *
 * <p>Os tipos do Netty chegam e saem como Object (o mod compila com o jogo, entao pode converte-los). Um mod so
 * por vez: registrar de novo troca o anterior, e null tira.
 */
public final class Net {

    /** Quem desvia a conexao. */
    public interface Proxy {
        /**
         * Para onde conectar de verdade.
         *
         * @param destination o InetAddress do servidor
         * @param port a porta dele
         * @return o SocketAddress por onde passar (o proxy), ou null para ir direto
         */
        Object address(Object destination, int port);

        /**
         * O inicializador de canal a usar: o do jogo monta a pilha de pacotes, e quem devolve outro pode por
         * handlers antes dele (um tunel, por exemplo).
         *
         * @param initializer o do jogo (ChannelHandler)
         * @return o mesmo, ou outro
         */
        Object wrap(Object initializer);
    }

    private Net() {
    }

    /** Registra (ou tira, com null) quem desvia a conexao. */
    public static void set(Proxy p) {
        Host.INSTANCE.setProxy(p);
    }

    /**
     * Manda um pacote de plugin ao servidor (C17PacketCustomPayload) no canal dado — o par do
     * {@link SteinMod#onCustomPayload}. Sem conexao, nao faz nada.
     *
     * @return true se foi para a fila de envio
     */
    @Experimental(since = "0.1.14")
    public static boolean sendPayload(String channel, byte[] data) {
        return Host.INSTANCE.sendPayload(channel, data);
    }
}
