package dev.xavier.stein.loader.api;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Uma opcao que o jogador mexe: botao que alterna ou percorre valores (botao esquerdo
 * avanca, o direito volta), acao, ou texto livre (campo). Tambem as cores de formatacao do jogo.
 *
 * <p>Serve nos dois lugares em que o jogador mexe em opcoes: as de um elemento do HUD (no editor da grade) e as de
 * um mod na {@link Page pagina} dele, no Painel (nasceu como HudOption, so para o HUD; o nome ficou generico quando
 * passou a servir tambem as paginas).
 */
public abstract class Option {

    /** Codigos de cor do jogo (0-9, a-f). */
    public static final String CODES = "0123456789abcdef";
    /** Cor de cada codigo, sem alfa. */
    public static final int[] RGB = {
        0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA,
        0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF,
    };

    public final String label;

    /**
     * Opcao de quem ja sabe o que quer: o Painel a guarda atras de "Mais opcoes", na propria secao. O padrao e
     * falso — so vai para la o que foi marcado.
     */
    private boolean advanced;

    protected Option(String label) {
        this.label = label;
    }

    /** A tecla que faz o mesmo que esta opcao, na propria linha ({@link #withKey}); null sem. */
    private Key key;

    /**
     * Poe a escolha de uma tecla na propria linha da opcao, ao lado do controle: um clique na etiqueta da tecla espera
     * a proxima tecla (Esc desiste), o direito limpa. E a tecla que liga e desliga uma funcionalidade ficar junto
     * dela, sem uma lista de teclas separada. Devolve esta opcao, para encadear.
     */
    @Experimental(since = "0.1.19")
    public Option withKey(IntSupplier get, IntConsumer set) {
        key = new Key(label, get, set);
        return this;
    }

    /** Quando a opcao aparece ({@link #visibleWhen}); null = sempre. */
    private java.util.function.BooleanSupplier visible;

    /**
     * A opcao so aparece enquanto {@code when} for verdade (o Painel confere a cada quadro): para um grupo de opcoes
     * que so faz sentido num modo (as de cada peca, no modo por peca). Devolve esta opcao, para encadear.
     */
    @Experimental(since = "0.1.19")
    public Option visibleWhen(java.util.function.BooleanSupplier when) {
        visible = when;
        return this;
    }

    /** A opcao aparece agora? */
    @Experimental(since = "0.1.19")
    public boolean isVisible() {
        return visible == null || visible.getAsBoolean();
    }

    /** A tecla da linha ({@link #withKey}), ou null. */
    @Experimental(since = "0.1.19")
    public Key key() {
        return key;
    }

    /** Marca esta opcao como avancada e devolve ela, para encadear na criacao. */
    public Option advanced() {
        advanced = true;
        return this;
    }

    public boolean isAdvanced() {
        return advanced;
    }

    /** E o "Restaurar padrao" de uma secao? A tela o desenha com icone e em outro tom. */
    public boolean isRestore() {
        return false;
    }

    public abstract String value();

    /** Botao esquerdo: proximo valor; direito: anterior. */
    public abstract void click(boolean forward);

    /**
     * Ligada ou desligada, para quem so tem dois estados; null para as outras. O Painel usa para resumir uma secao
     * fechada ("9 de 14") sem precisar saber o que cada opcao e.
     */
    public Boolean state() {
        return null;
    }

    public String text() {
        return label + ": " + value();
    }

    /** Indice (0-15) de um codigo de cor ("f", "c"...); desconhecido = branco. */
    public static int colorIndex(String code) {
        int i = code == null || code.isEmpty() ? -1 : CODES.indexOf(Character.toLowerCase(code.charAt(0)));
        return i < 0 ? 15 : i;
    }

    public static int rgb(String code) {
        return RGB[colorIndex(code)];
    }

    /** Prefixo de formatacao (secao + codigo) para uma string colorida. */
    public static String fmt(String code) {
        return "§" + CODES.charAt(colorIndex(code));
    }

    /** Nome da cor, no idioma do jogo. */
    public static String colorName(String code) {
        return Lang.tr("steinloader.color." + CODES.charAt(colorIndex(code)));
    }

    public static Option toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        return new Option(label) {
            @Override
            public String value() {
                return get.getAsBoolean() ? "§a" + Lang.tr("gui.yes") : "§c" + Lang.tr("gui.no");
            }

            @Override
            public Boolean state() {
                return get.getAsBoolean();
            }

            @Override
            public void click(boolean forward) {
                set.accept(!get.getAsBoolean());
            }
        };
    }

    public static Option cycle(String label, String[] names, IntSupplier get, IntConsumer set) {
        return new Option(label) {
            @Override
            public String value() {
                int i = get.getAsInt();
                return i >= 0 && i < names.length ? names[i] : "?";
            }

            @Override
            public void click(boolean forward) {
                int n = names.length;
                set.accept(((get.getAsInt() + (forward ? 1 : -1)) % n + n) % n);
            }
        };
    }

    public static Option color(String label, Supplier<String> get, Consumer<String> set) {
        return new Option(label) {
            @Override
            public String value() {
                return fmt(get.get()) + colorName(get.get());
            }

            @Override
            public void click(boolean forward) {
                int i = (colorIndex(get.get()) + (forward ? 1 : 15)) % 16;
                set.accept(String.valueOf(CODES.charAt(i)));
            }
        };
    }

    public static Option action(String label, String value, Runnable run) {
        return new Option(label) {
            @Override
            public String value() {
                return value;
            }

            @Override
            public void click(boolean forward) {
                run.run();
            }
        };
    }

    /**
     * "Restaurar padrao", o mesmo nome e o mesmo jeito em todo lugar: o primeiro clique pede confirmacao ("Confirmar?"
     * por 3 segundos) e so o segundo roda — voltar tudo ao padrao por um clique sem querer apagaria o que o jogador
     * levou tempo para escolher. Cada secao do Painel tem o seu, logo no fim dela.
     */
    public static Option restore(Runnable run) {
        return new Option(Lang.tr("steinloader.restore")) {
            private long until;

            @Override
            public boolean isRestore() {
                return true;
            }

            @Override
            public String value() {
                return System.nanoTime() < until ? "§e" + Lang.tr("steinloader.confirm") : "";
            }

            @Override
            public void click(boolean forward) {
                if (System.nanoTime() < until) {
                    until = 0;
                    run.run();
                } else {
                    until = System.nanoTime() + 3_000_000_000L;
                }
            }
        };
    }

    /**
     * Numero entre {@code min} e {@code max}, de {@code step} em {@code step}: uma trilha que se arrasta no Painel. Em
     * qualquer tela, o clique esquerdo sobe um passo e o direito desce (no editor de HUD, que nao arrasta).
     *
     * @param format o texto do valor (ex. {@code v -> (int) (v * 100) + "%"}); null mostra o numero
     */
    @Experimental(since = "0.1.15")
    public static Slider slider(String label, double min, double max, double step, DoubleSupplier get,
            DoubleConsumer set, java.util.function.DoubleFunction<String> format) {
        return new Slider(label, min, max, step, get, set, format);
    }

    /** Escolher uma tecla: o clique espera a proxima tecla, Esc desiste, o clique direito limpa (0 = nenhuma). */
    @Experimental(since = "0.1.15")
    public static Key key(String label, IntSupplier get, IntConsumer set) {
        return new Key(label, get, set);
    }

    @Experimental(since = "0.1.15")
    public static final class Slider extends Option {
        public final double min;
        public final double max;
        public final double step;
        private final DoubleSupplier get;
        private final DoubleConsumer set;
        private final java.util.function.DoubleFunction<String> format;

        Slider(String label, double min, double max, double step, DoubleSupplier get, DoubleConsumer set,
                java.util.function.DoubleFunction<String> format) {
            super(label);
            this.min = min;
            this.max = Math.max(min, max);
            this.step = step > 0 ? step : 0;
            this.get = get;
            this.set = set;
            this.format = format;
        }

        public double get() {
            return get.getAsDouble();
        }

        /** Grava o valor preso ao intervalo e ao passo. */
        public void set(double v) {
            double c = Math.max(min, Math.min(max, v));
            if (step > 0) {
                c = Math.max(min, Math.min(max, min + Math.round((c - min) / step) * step));
            }
            set.accept(c);
        }

        /** Onde o valor esta na trilha, de 0 a 1. */
        public float fraction() {
            return max == min ? 0 : (float) ((get() - min) / (max - min));
        }

        /** Grava pela posicao na trilha (0 a 1): o arrasto. */
        public void setFraction(float f) {
            set(min + Math.max(0, Math.min(1, f)) * (max - min));
        }

        @Override
        public String value() {
            double v = get();
            if (format != null) {
                return format.apply(v);
            }
            return v == Math.rint(v) && Math.abs(v) < 1e9 ? String.valueOf((long) v) : String.format("%.2f", v);
        }

        @Override
        public void click(boolean forward) {
            double by = step > 0 ? step : (max - min) / 20;
            set(get() + (forward ? by : -by));
        }
    }

    @Experimental(since = "0.1.15")
    public static final class Key extends Option {
        private final IntSupplier get;
        private final IntConsumer set;
        private boolean listening;

        Key(String label, IntSupplier get, IntConsumer set) {
            super(label);
            this.get = get;
            this.set = set;
        }

        /** Esperando a tecla? A tela manda a proxima para {@link #keyPressed}. */
        public boolean isListening() {
            return listening;
        }

        /**
         * A tecla que chegou enquanto esperava. Esc desiste sem mudar nada.
         *
         * @return true se a tecla foi usada aqui (a tela nao faz mais nada com ela)
         */
        public boolean keyPressed(int keyCode) {
            if (!listening) {
                return false;
            }
            listening = false;
            if (keyCode != 1) {
                set.accept(keyCode);
            }
            return true;
        }

        @Override
        public String value() {
            if (listening) {
                return "§e> " + Lang.tr("steinloader.key.press") + " <";
            }
            int code = get.getAsInt();
            return code == 0 ? "§7" + Lang.tr("steinloader.key.none")
                    : net.minecraft.client.settings.GameSettings.getKeyDisplayString(code);
        }

        @Override
        public void click(boolean forward) {
            if (forward) {
                listening = !listening;
            } else {
                listening = false;
                set.accept(0);
            }
        }
    }

    /** Texto livre (ex. uma lista de cores): um campo de texto, nao um botao. Um por elemento. */
    public static final class Text extends Option {
        public final Supplier<String> get;
        public final Consumer<String> set;
        public final String hint;
        /** Senha: a tela mostra pontos no lugar das letras. */
        public final boolean secret;

        public Text(String label, String hint, Supplier<String> get, Consumer<String> set) {
            this(label, hint, get, set, false);
        }

        public Text(String label, String hint, Supplier<String> get, Consumer<String> set, boolean secret) {
            super(label);
            this.hint = hint;
            this.get = get;
            this.set = set;
            this.secret = secret;
        }

        @Override
        public String value() {
            return get.get();
        }

        @Override
        public void click(boolean forward) {
        }
    }
}
