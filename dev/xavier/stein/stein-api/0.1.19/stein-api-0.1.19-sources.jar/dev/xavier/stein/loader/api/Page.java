package dev.xavier.stein.loader.api;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/**
 * O que um mod oferece ao jogador durante a partida: a pagina dele no Painel (Shift direito), preenchida no
 * {@link SteinMod#onPage}.
 *
 * <p>O mod so descreve; quem desenha e o Loader — assim todos os mods ficam iguais na tela, ninguem escreve GUI de
 * novo e a mesma pagina pode ser mostrada em outro lugar depois. A pagina e montada toda vez que o Painel abre,
 * entao os valores estao sempre frescos.
 *
 * <p>Tudo fica na propria pagina, sem submenu: {@link #section} (um titulo), {@link #option} (a opcao, clicada ali
 * mesmo — inclusive {@link Option.Text}, que vira campo de texto) e {@link #items} (uma lista de coisas que se
 * clica para tirar). So o que nao e configuracao — o editor da grade, que se usa arrastando no mundo — abre tela a
 * parte, pelo {@link #screen}.
 */
public final class Page {

    /**
     * Uma coisa de uma lista do mod: uma conta, um proxy. Tem nome, um detalhe a direita, se e a que esta em uso
     * agora, o que fazer ao clicar nela e (quando da para tirar) o que fazer no clique da lixeira.
     *
     * <p>Existe porque {@link #items} nao dava conta do que estas listas precisam: ali um clique so faz uma coisa,
     * e escolher e apagar sao duas — quem vai trocar de conta nao pode correr o risco de apagar uma no lugar.
     */
    public static final class Item {
        public final String title;
        public final String detail;
        public final boolean current;
        public final Runnable use;
        /** O que fazer para tirar da lista, ou null quando nao da para tirar. */
        public final Runnable remove;

        public Item(String title, String detail, boolean current, Runnable use, Runnable remove) {
            this.title = title == null ? "" : title;
            this.detail = detail == null ? "" : detail;
            this.current = current;
            this.use = use;
            this.remove = remove;
        }
    }

    /** Uma linha da pagina: titulo de secao, opcao, ou algo que abre uma tela. */
    public static final class Entry {
        /** Titulo da secao, ou null. */
        public final String section;
        /** A opcao, ou null. */
        public final Option option;
        /** Rotulo do que abre tela, ou null. */
        public final String label;
        /** Recebe a tela de onde veio (para voltar) e devolve a tela a abrir (GuiScreen), ou null. */
        public final Function<Object, Object> screen;

        /** Lista clicavel, ou null. */
        public final java.util.function.Supplier<List<String>> items;
        /** O que fazer com o item clicado, ou null. */
        public final java.util.function.Consumer<String> onClick;
        /** Texto de lista vazia, ou null. */
        public final String empty;
        /** O clique tira o item da lista (vermelho sob o mouse) em vez de escolher. */
        public final boolean removes;
        /** Lista de {@link Item} (uma linha por coisa, com lixeira), ou null. */
        public final java.util.function.Supplier<List<Item>> rows;

        private Entry(String section, Option option, String label, Function<Object, Object> screen,
                java.util.function.Supplier<List<String>> items, java.util.function.Consumer<String> onClick,
                String empty, boolean removes, java.util.function.Supplier<List<Item>> rows) {
            this.section = section;
            this.option = option;
            this.label = label;
            this.screen = screen;
            this.items = items;
            this.onClick = onClick;
            this.empty = empty;
            this.removes = removes;
            this.rows = rows;
        }
    }

    private String title;
    private String icon = "";
    private final List<Entry> entries = new ArrayList<>();

    public Page(String title) {
        this.title = title;
    }

    /** Nome da pagina, na coluna da esquerda. Por padrao e o nome do mod. */
    public String title() {
        return title;
    }

    /**
     * Outro nome para a pagina, quando o nome do mod nao descreve o que ha nela — a pagina do Stein HUD, por
     * exemplo, so tem a lista do Tab, e duas paginas "HUD" na lista da esquerda nao dizem qual e qual.
     */
    public Page title(String name) {
        if (name != null && !name.isEmpty()) {
            this.title = name;
        }
        return this;
    }

    /**
     * Qual desenho representa a pagina na trilha do Painel, entre os icones do Stein (os mesmos do Stein Client, so de
     * traco): {@code "screen"}, {@code "combat"}, {@code "link"}, {@code "list"}, {@code "gear"}, {@code "grid"},
     * {@code "users"}, {@code "layers"}, {@code "shield"}, {@code "clock"}, {@code "check"}, {@code "bolt"},
     * {@code "lock"}, {@code "key"}, {@code "search"}, {@code "star"}, {@code "heart"}, {@code "pin"}, {@code "ping"},
     * {@code "folder"}, {@code "sword"}, {@code "loop"}. Sem icone (ou com um nome que nao existe), a pagina aparece
     * com a inicial do nome num circulo.
     */
    public Page icon(String name) {
        this.icon = name == null ? "" : name;
        return this;
    }

    public String icon() {
        return icon;
    }

    public List<Entry> entries() {
        return entries;
    }

    public boolean isEmpty() {
        return entries.isEmpty();
    }

    /** O "Restaurar padrao" da secao de agora ({@link Option#restore}), no fim dela. */
    public Page restore(Runnable run) {
        return option(Option.restore(run));
    }

    /** Titulo que separa um assunto do proximo. */
    public Page section(String title) {
        entries.add(new Entry(title, null, null, null, null, null, null, false, null));
        return this;
    }

    /** Uma opcao, clicada na propria linha (esquerdo avanca, direito volta). */
    public Page option(Option option) {
        entries.add(new Entry(null, option, null, null, null, null, null, false, null));
        return this;
    }

    /**
     * Uma lista de coisas que o jogador clica para tirar (aliados, atalhos): elas aparecem em fila, quebrando linha,
     * e o clique chama {@code onClick}. A lista e lida na hora de desenhar, entao acrescentar ou tirar aparece na
     * mesma abertura.
     */
    public Page items(java.util.function.Supplier<List<String>> get, java.util.function.Consumer<String> onClick,
            String empty, boolean removes) {
        entries.add(new Entry(null, null, null, null, get, onClick, empty, removes, null));
        return this;
    }

    /**
     * Uma lista de coisas do mod, uma por linha: nome, detalhe e a lixeira de tirar. O clique na linha usa aquela
     * coisa; o clique na lixeira tira. E o que serve para contas e para proxies, onde escolher e apagar precisam
     * ser dois gestos diferentes.
     *
     * @param get a lista de agora (lida na hora de desenhar, entao acrescentar e tirar aparece na mesma abertura)
     * @param empty o que dizer quando nao ha nenhuma
     */
    public Page rows(java.util.function.Supplier<List<Item>> get, String empty) {
        entries.add(new Entry(null, null, null, null, null, null, empty, false, get));
        return this;
    }

    /**
     * Abre uma tela do mod, para o que nao e configuracao — o editor da grade, que se usa arrastando no mundo. A
     * funcao recebe a tela de onde veio — guarde-a para voltar a ela quando o jogador concluir.
     */
    public Page screen(String label, Function<Object, Object> open) {
        entries.add(new Entry(null, null, label, open, null, null, null, false, null));
        return this;
    }
}
