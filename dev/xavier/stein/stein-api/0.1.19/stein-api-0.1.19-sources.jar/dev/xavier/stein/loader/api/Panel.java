package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Abrir o Painel (o que o jogador mexe durante a partida) de dentro de um mod — para um botao numa tela do jogo
 * levar direto a pagina dele, em vez de pedir a tecla.
 */
public final class Panel {

    private Panel() {
    }

    /** Abre o Painel sobre a tela dada (GuiScreen), na pagina de nome page (o nome do mod); null abre na ultima aberta. */
    public static void open(Object parent, String page) {
        Host.INSTANCE.openPanel(parent, page, false);
    }

    /**
     * Abre o Painel so com a pagina dada, sem a lista das outras: quem chega por um botao do mod (a conta, na lista de
     * servidores) ve so o que e daquele mod, e Esc volta para a tela de onde veio.
     */
    public static void openOnly(Object parent, String page) {
        Host.INSTANCE.openPanel(parent, page, true);
    }

    /**
     * Fecha o Painel e volta para a tela de onde ele veio. E o que o mod chama quando o que o jogador escolheu ja
     * resolveu o que ele foi fazer ali — escolher a conta na lista de servidores, por exemplo: escolheu, voltou
     * para a lista, e nao fica preso numa tela que ja cumpriu o papel.
     */
    public static void close() {
        Host.INSTANCE.closePanel();
    }

    /** Abre o Painel na ultima pagina aberta. */
    public static void open(Object parent) {
        open(parent, null);
    }
}
