package dev.xavier.stein.loader.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Os jogadores do servidor como o cliente os conhece: a lista do Tab, o time do placar de cada um e o grupo.
 *
 * <p>Vale para quem esta online no Tab, perto ou longe; quem nao esta no Tab (NPC, jogador escondido pelo servidor)
 * responde null/vazio. Chame da thread do jogo.
 */
@Experimental(since = "0.1.16")
public final class Players {

    private static final Pattern NICK = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private static final Map<String, String> GROUPS = new HashMap<>();
    private static long groupsAt;

    private Players() {
    }

    /** O seu nick, ou null fora do mundo. */
    public static String self() {
        return Host.INSTANCE.selfName();
    }

    /** Os nicks da lista do Tab. */
    public static List<String> online() {
        return Host.INSTANCE.onlinePlayers();
    }

    /** O nome do time do placar do jogador, ou null. */
    public static String team(String nick) {
        return Host.INSTANCE.playerTeam(nick);
    }

    /** O prefixo do time (com os codigos de cor), ou "". */
    public static String prefix(String nick) {
        return Host.INSTANCE.playerPrefix(nick);
    }

    /** O sufixo do time (com os codigos de cor), ou "". */
    public static String suffix(String nick) {
        return Host.INSTANCE.playerSuffix(nick);
    }

    /** O nome como o Tab mostra (o do servidor, ou prefixo + nick + sufixo), com os codigos de cor; null se nao esta. */
    public static String tabName(String nick) {
        return Host.INSTANCE.playerTabName(nick);
    }

    /**
     * So o nome que o <b>servidor</b> manda para o Tab (com os codigos de cor), ou null quando ele nao manda nenhum e
     * o Tab monta o nome pelo time. E ali que muito servidor poe o cla: "[ABC] Nick".
     */
    public static String displayName(String nick) {
        return Host.INSTANCE.playerDisplayName(nick);
    }

    /** O nick de uma linha do Tab (o NetworkPlayerInfo que onPlayerListName e onPlayerList recebem), ou null. */
    public static String nickOf(Object playerInfo) {
        return Host.INSTANCE.playerInfoNick(playerInfo);
    }

    /** O ping do jogador no Tab, em ms, ou -1. */
    public static int ping(String nick) {
        return Host.INSTANCE.playerPing(nick);
    }

    /**
     * O grupo do jogador (cla, time, guilda — o nome que o servidor usar), ou null. Quem sabe a convencao do servidor
     * registra um {@link #groupResolver}; sem nenhum que responda, vale o jeito mais comum: o que esta entre colchetes
     * no prefixo do time ("§b[ABC] " -> "ABC") ou, sem isso, no nome que o servidor manda para o Tab ("[ABC] Nick").
     * Guardado por um segundo: pode ser perguntado por jogador a cada quadro sem varrer o Tab.
     */
    public static String group(String nick) {
        if (nick == null) {
            return null;
        }
        long now = System.nanoTime();
        if (now - groupsAt > 1_000_000_000L) {
            GROUPS.clear();
            groupsAt = now;
        }
        if (GROUPS.containsKey(nick)) {
            return GROUPS.get(nick);
        }
        String tag = null;
        for (java.util.function.Function<String, String> r : RESOLVERS.values()) {
            try {
                tag = r.apply(nick);
            } catch (RuntimeException e) {
                Log.of("players").error("quem descobre o grupo falhou", e);
            }
            if (tag != null) {
                break;
            }
        }
        if (tag != null && tag.isEmpty()) {
            tag = null;   // quem conhece o servidor decidiu: sem grupo
        } else if (tag == null) {
            tag = bracketTag(prefix(nick));
        }
        if (tag == null) {
            tag = bracketTag(tabName(nick));
        }
        GROUPS.put(nick, tag);
        return tag;
    }

    private static final Map<String, java.util.function.Function<String, String>> RESOLVERS =
            new java.util.LinkedHashMap<>();

    /**
     * Registra (ou, com null, tira) quem descobre o grupo de um jogador neste servidor — um mod que conhece a
     * convencao dele (um time com nome especial, uma regra de tag). Devolve o grupo; "" para "sem grupo" (decidido: o
     * jeito comum nem e tentado); null para deixar com os outros — na ordem de
     * registro, o primeiro que responder vale, e so sem nenhum vale o jeito comum ({@link #group}).
     */
    public static void groupResolver(String source, java.util.function.Function<String, String> resolver) {
        if (resolver == null) {
            RESOLVERS.remove(source);
        } else {
            RESOLVERS.put(source, resolver);
        }
        GROUPS.clear();
        Relations.changed();
    }

    /** A tag entre colchetes de um texto, sem cores e sem espacos ("§b[ ABC ] Nick" -> "ABC"), ou null. */
    public static String bracketTag(String text) {
        if (text == null) {
            return null;
        }
        String clean = text.replaceAll("§.", "").trim();
        int open = clean.indexOf('[');
        int close = clean.indexOf(']', open + 1);
        if (open < 0 || close <= open + 1) {
            return null;
        }
        String t = clean.substring(open + 1, close).trim();
        return t.isEmpty() ? null : t;
    }

    /** Um nick possivel de Minecraft (letras, numeros e _, de 1 a 16)? */
    public static boolean isValidNick(String s) {
        return s != null && NICK.matcher(s).matches();
    }

    /** Uma linha da lista do Tab, lida de uma vez ({@link #list}). */
    public static final class Entry {
        public final String nick;
        /** Como o Tab mostra (o nome do servidor, ou prefixo + nick + sufixo do time), com cores. */
        public final String tabName;
        /** O nome do time do placar, ou "". */
        public final String team;
        /** Ms; 0 enquanto o servidor nao mediu. */
        public final int ping;
        public final boolean spectator;
        /** O servidor mandou uma skin (senao o jogo mostra a padrao: servidor sem autenticacao). */
        public final boolean hasSkin;

        public Entry(String nick, String tabName, String team, int ping, boolean spectator, boolean hasSkin) {
            this.nick = nick;
            this.tabName = tabName;
            this.team = team;
            this.ping = ping;
            this.spectator = spectator;
            this.hasSkin = hasSkin;
        }
    }

    /**
     * A lista do Tab inteira numa volta so, para quem a desenha ou ordena. Com centenas de jogadores, perguntar
     * {@link #tabName}, {@link #ping} e {@link #team} nick por nick custa uma busca por jogador; aqui e uma lista nova
     * por chamada — guarde e refaca por tick, nao por quadro.
     */
    @Experimental(since = "0.1.16")
    public static List<Entry> list() {
        return Host.INSTANCE.playerList();
    }

    /** Quantos estao na lista do Tab (sem montar a lista): para saber quando refazer o que foi montado com {@link #list}. */
    @Experimental(since = "0.1.16")
    public static int count() {
        return Host.INSTANCE.playerCount();
    }

    /** O texto que o servidor poe acima da lista do Tab (com cores), ou null. */
    @Experimental(since = "0.1.16")
    public static String tabHeader() {
        return Host.INSTANCE.tabText(true);
    }

    /** O texto abaixo da lista do Tab, ou null. */
    @Experimental(since = "0.1.16")
    public static String tabFooter() {
        return Host.INSTANCE.tabText(false);
    }

    /** O placar da lista do Tab (a coluna de numero, como vida ou abates) desse jogador, ou null sem placar na lista. */
    @Experimental(since = "0.1.16")
    public static String listScore(String nick) {
        return Host.INSTANCE.listScore(nick);
    }
}
