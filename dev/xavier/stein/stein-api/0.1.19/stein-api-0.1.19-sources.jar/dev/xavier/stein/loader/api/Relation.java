package dev.xavier.stein.loader.api;

/** O que um jogador e para voce ({@link Relations}). */
@Experimental(since = "0.1.16")
public enum Relation {
    /** Ninguem cadastrou nada nem ha fornecedor: nao se sabe. */
    NONE,
    /** Voce. */
    SELF,
    /** Do seu grupo (cla, time, guilda — o nome e de quem cadastra: {@link Relations#setGroup}). */
    GROUP,
    ALLY,
    ENEMY,
    /** Sabe-se que nao e nem aliado nem inimigo. */
    NEUTRAL;

    /** Do seu lado (voce, seu grupo, aliado)? */
    public boolean friendly() {
        return this == SELF || this == GROUP || this == ALLY;
    }
}
