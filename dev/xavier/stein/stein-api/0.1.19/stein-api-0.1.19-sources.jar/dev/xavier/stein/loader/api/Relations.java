package dev.xavier.stein.loader.api;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Quem e aliado e quem e inimigo, num lugar so, para todos os mods. So dados e avisos: nada aqui protege, esconde ou
 * pinta ninguem — isso e de quem consulta.
 *
 * <p>Tres jeitos de dizer a relacao, cada um com uma origem ({@code source}, em geral o id do mod), para cada um
 * apagar so o que e seu:
 * <ul>
 *   <li><b>Jogador</b>: {@link #setPlayer}.</li>
 *   <li><b>Grupo</b>: {@link #setGroup} — vale para todos daquele grupo ({@link Players#group}): cla, time, guilda,
 *       com o nome que for. {@link Relation#GROUP} marca o seu proprio grupo.</li>
 *   <li><b>Fornecedor</b>: {@link #register} — um mod que decide sozinho (listas por URL, regras de um servidor).</li>
 * </ul>
 *
 * <p>Ordem de quem decide, em {@link #of}: voce mesmo ({@link Relation#SELF}); o jogador cadastrado (entre origens,
 * inimigo ganha de aliado, que ganha de neutro); os fornecedores, na ordem de registro, o primeiro que responder; o
 * grupo cadastrado; e, havendo qualquer cadastro ou fornecedor, {@link Relation#NEUTRAL} — sem nada, {@link Relation#NONE}.
 *
 * <p>Pode ser consultado por jogador a cada quadro: a resposta fica guardada ate o proximo {@link #version} (ou um
 * segundo, porque o grupo vem do placar). Mudou algo, os mods recebem {@link SteinMod#onRelationsChanged}.
 */
@Experimental(since = "0.1.16")
public final class Relations {

    /** Um mod que decide relacoes sozinho. */
    @FunctionalInterface
    public interface Provider {
        /**
         * @param nick o jogador
         * @param group o grupo dele ({@link Players#group}), ou null
         * @return a relacao, ou null para deixar com os outros
         */
        Relation relationOf(String nick, String group);
    }

    private static final Map<String, Map<String, Relation>> PLAYERS = new HashMap<>();   // nick minusculo -> origem -> r
    private static final Map<String, Map<String, Relation>> GROUPS = new HashMap<>();     // nome do grupo em maiusculas -> origem -> r
    private static final Map<String, Provider> PROVIDERS = new LinkedHashMap<>();
    private static final Map<Relation, Integer> COLORS = new EnumMap<>(Relation.class);
    private static final Map<String, Relation> CACHE = new HashMap<>();
    private static int version;
    private static int cacheVersion = -1;
    private static long cacheAt;

    static {
        COLORS.put(Relation.NONE, 0xFFFFFF);
        COLORS.put(Relation.SELF, 0xFFFFFF);
        COLORS.put(Relation.GROUP, 0x55FF55);
        COLORS.put(Relation.ALLY, 0x5555FF);
        COLORS.put(Relation.ENEMY, 0xFF5555);
        COLORS.put(Relation.NEUTRAL, 0xFFFFFF);
    }

    private Relations() {
    }

    // --- consultar ---

    /** A relacao com o jogador. */
    public static Relation of(String nick) {
        if (nick == null) {
            return Relation.NONE;
        }
        long now = System.nanoTime();
        if (cacheVersion != version || now - cacheAt > 1_000_000_000L) {
            CACHE.clear();
            cacheVersion = version;
            cacheAt = now;
        }
        Relation r = CACHE.get(nick);
        if (r == null) {
            r = resolve(nick);
            CACHE.put(nick, r);
        }
        return r;
    }

    /** A relacao com a entidade: jogador pelo nick; outra entidade, {@link Relation#NONE}. */
    public static Relation of(Object entity) {
        return of(Host.INSTANCE.playerNameOf(entity));
    }

    /** A cor escolhida para a relacao (RGB, sem alfa). */
    public static int color(Relation r) {
        return COLORS.getOrDefault(r, 0xFFFFFF);
    }

    /** Sobe a cada mudanca (cadastro, fornecedor, cor, {@link #changed}): quem guarda algo confere por ele. */
    public static int version() {
        return version;
    }

    /** Os jogadores cadastrados com essa relacao (por qualquer origem), em minusculas. */
    public static List<String> players(Relation r) {
        List<String> out = new ArrayList<>();
        PLAYERS.forEach((nick, by) -> {
            if (strongest(by) == r) {
                out.add(nick);
            }
        });
        return out;
    }

    /** Os grupos cadastrados com essa relacao, em maiusculas. */
    public static List<String> groups(Relation r) {
        List<String> out = new ArrayList<>();
        GROUPS.forEach((tag, by) -> {
            if (strongest(by) == r) {
                out.add(tag);
            }
        });
        return out;
    }

    // --- dizer ---

    /** Cadastra (ou, com null, tira) a relacao com o jogador, pela origem. */
    public static void setPlayer(String source, String nick, Relation r) {
        if (nick != null && put(PLAYERS, nick.toLowerCase(Locale.ROOT), source, r)) {
            changed();
        }
    }

    /** Cadastra (ou, com null, tira) a relacao com o grupo (nome livre, sem diferenca de maiusculas), pela origem.
     * {@link Relation#GROUP} = o seu grupo. */
    public static void setGroup(String source, String tag, Relation r) {
        if (tag != null && put(GROUPS, tag.trim().toUpperCase(Locale.ROOT), source, r)) {
            changed();
        }
    }

    /** Tira tudo o que a origem cadastrou (jogadores e grupos). */
    public static void clear(String source) {
        boolean any = removeSource(PLAYERS, source) | removeSource(GROUPS, source);
        if (any) {
            changed();
        }
    }

    /** Registra (ou troca) o fornecedor da origem. */
    public static void register(String source, Provider provider) {
        PROVIDERS.put(source, provider);
        changed();
    }

    public static void unregister(String source) {
        if (PROVIDERS.remove(source) != null) {
            changed();
        }
    }

    /** Troca a cor de uma relacao (quem deixa o jogador escolher chama isto). */
    public static void setColor(Relation r, int rgb) {
        Integer old = COLORS.put(r, rgb & 0xFFFFFF);
        if (old == null || old != (rgb & 0xFFFFFF)) {
            changed();
        }
    }

    /**
     * Avisa que as respostas de um fornecedor mudaram (uma lista baixada, uma opcao trocada): a resposta guardada cai
     * e os mods recebem {@link SteinMod#onRelationsChanged} no fim do tick.
     */
    public static void changed() {
        version++;
        Host.INSTANCE.relationsChanged();
    }

    // --- por dentro ---

    private static Relation resolve(String nick) {
        String self = Players.self();
        if (self != null && self.equalsIgnoreCase(nick)) {
            return Relation.SELF;
        }
        Map<String, Relation> by = PLAYERS.get(nick.toLowerCase(Locale.ROOT));
        if (by != null && !by.isEmpty()) {
            return strongest(by);
        }
        String group = Players.group(nick);
        for (Provider p : PROVIDERS.values()) {
            try {
                Relation r = p.relationOf(nick, group);
                if (r != null) {
                    return r;
                }
            } catch (RuntimeException e) {
                Log.of("relations").error("fornecedor de relacoes falhou", e);
            }
        }
        if (group != null) {
            Map<String, Relation> c = GROUPS.get(group.toUpperCase(Locale.ROOT));
            if (c != null && !c.isEmpty()) {
                return strongest(c);
            }
        }
        return PLAYERS.isEmpty() && GROUPS.isEmpty() && PROVIDERS.isEmpty() ? Relation.NONE : Relation.NEUTRAL;
    }

    /** Entre origens: seu grupo, depois inimigo, aliado, neutro. */
    private static Relation strongest(Map<String, Relation> by) {
        Relation best = null;
        for (Relation r : by.values()) {
            if (best == null || rank(r) > rank(best)) {
                best = r;
            }
        }
        return best == null ? Relation.NONE : best;
    }

    private static int rank(Relation r) {
        return switch (r) {
            case SELF -> 5;
            case GROUP -> 4;
            case ENEMY -> 3;
            case ALLY -> 2;
            case NEUTRAL -> 1;
            case NONE -> 0;
        };
    }

    private static boolean put(Map<String, Map<String, Relation>> map, String key, String source, Relation r) {
        if (r == null) {
            Map<String, Relation> by = map.get(key);
            if (by == null || by.remove(source) == null) {
                return false;
            }
            if (by.isEmpty()) {
                map.remove(key);
            }
            return true;
        }
        return map.computeIfAbsent(key, k -> new HashMap<>()).put(source, r) != r;
    }

    private static boolean removeSource(Map<String, Map<String, Relation>> map, String source) {
        boolean any = false;
        for (var it = map.values().iterator(); it.hasNext(); ) {
            Map<String, Relation> by = it.next();
            any |= by.remove(source) != null;
            if (by.isEmpty()) {
                it.remove();
            }
        }
        return any;
    }
}
