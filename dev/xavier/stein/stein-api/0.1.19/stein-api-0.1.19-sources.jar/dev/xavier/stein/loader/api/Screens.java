package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * As telas do jogo e os botoes delas, para quem poe um botao numa tela do jogo ({@link SteinMod#onGuiInit}) ou
 * precisa saber onde o jogador esta. Telas e botoes sao tipos do jogo e passam como Object. Chame da thread do jogo.
 *
 * <pre>
 * public void onGuiInit(Object screen, List&lt;Object&gt; buttons) {
 *     if (Screens.kind(screen) == Screens.Kind.MULTIPLAYER) {
 *         buttons.add(Screens.button(MEU_ID, Screens.width(screen) - 124, 4, 120, 20, "Meu botao"));
 *     }
 * }
 * public boolean onGuiAction(Object screen, Object button) {
 *     return Screens.buttonId(button) == MEU_ID &amp;&amp; fazAlgo();
 * }
 * </pre>
 *
 * <p>Ids de botao: use numeros longe dos do jogo (que ficam abaixo de 1000), como {@code 0x5E000 + n}.
 */
@Experimental(since = "0.1.16")
public final class Screens {

    /** Que tela e. Tela de mod ou uma do jogo que nao esta aqui: {@link #OTHER}. */
    public enum Kind {
        /** Nenhuma tela: o jogador esta no mundo. */
        NONE,
        MAIN_MENU,
        SINGLEPLAYER,
        MULTIPLAYER,
        /** "Conectando ao servidor..." (o endereco: {@link Server#connectingAddress}). */
        CONNECTING,
        /** A tela de desconexao, com o motivo (ver {@link SteinMod#onDisconnected}). */
        DISCONNECTED,
        /** O menu do Esc. */
        PAUSE,
        OPTIONS,
        CHAT,
        /** O inventario do jogador (o do E) ou o do criativo. */
        INVENTORY,
        /** Bau, fornalha, bancada e toda outra tela com slots. */
        CONTAINER,
        /** O Painel e as telas do Stein Loader. */
        STEIN,
        OTHER
    }

    private static final Kind[] KINDS = Kind.values();

    private Screens() {
    }

    /** A tela aberta, ou null no mundo. */
    public static Object current() {
        return Host.INSTANCE.screenCurrent();
    }

    /** Que tela e esta (null = {@link Kind#NONE}). */
    public static Kind kind(Object screen) {
        return KINDS[Host.INSTANCE.screenKind(screen)];
    }

    /** Que tela esta aberta. */
    public static Kind currentKind() {
        return kind(current());
    }

    /** Ha uma tela aberta (qualquer uma, ate o chat)? */
    public static boolean isOpen() {
        return current() != null;
    }

    /** Largura da tela, na escala da interface (a mesma dos botoes). */
    public static int width(Object screen) {
        return Host.INSTANCE.screenWidth(screen);
    }

    /** Altura da tela, na escala da interface. */
    public static int height(Object screen) {
        return Host.INSTANCE.screenHeight(screen);
    }

    /** Abre uma tela (null fecha a atual e volta ao mundo). */
    public static void open(Object screen) {
        Host.INSTANCE.screenOpen(screen);
    }

    /** Um botao do jogo, para a lista do {@link SteinMod#onGuiInit}. */
    public static Object button(int id, int x, int y, int width, int height, String label) {
        return Host.INSTANCE.buttonNew(id, x, y, width, height, label);
    }

    /** O id do botao, ou -1 se nao for um botao. */
    public static int buttonId(Object button) {
        return Host.INSTANCE.buttonId(button);
    }

    /** O botao desta lista com esse id, ou null. */
    public static Object findButton(java.util.List<Object> buttons, int id) {
        for (Object b : buttons) {
            if (buttonId(b) == id) {
                return b;
            }
        }
        return null;
    }

    public static int buttonX(Object button) {
        return Host.INSTANCE.buttonX(button);
    }

    public static int buttonY(Object button) {
        return Host.INSTANCE.buttonY(button);
    }

    /** Troca o texto do botao (uma contagem, um estado). */
    public static void setLabel(Object button, String label) {
        Host.INSTANCE.buttonLabel(button, label);
    }

    /** Liga ou desliga o botao (desligado fica cinza e nao responde). */
    public static void setEnabled(Object button, boolean enabled) {
        Host.INSTANCE.buttonEnabled(button, enabled);
    }
}
