package dev.xavier.stein.loader.api;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Senhas e tokens de um mod fora do JSON de configuracao, em {@code config/<id>.secrets}.
 *
 * <p>No Windows cada valor e cifrado pelo proprio sistema (DPAPI, a protecao de dados do usuario): o arquivo so abre
 * na mesma conta do Windows, na mesma maquina — copiado para outro lugar, nao serve. Nos outros sistemas, por
 * enquanto, o valor so e embaralhado e o arquivo fica legivel so pelo dono: e melhor que texto puro num JSON, mas nao
 * e um cofre. Nunca escreva o valor no log.
 */
@Experimental(since = "0.1.16")
public final class Secrets {

    private final String id;

    private Secrets(String id) {
        this.id = id;
    }

    public static Secrets of(String modId) {
        return new Secrets(modId);
    }

    /** O valor guardado, ou null (nao ha, ou nao abre nesta conta/maquina). */
    public String get(String key) {
        String stored = read().get(key);
        if (stored == null) {
            return null;
        }
        try {
            byte[] plain = Host.INSTANCE.unprotect(Base64.getDecoder().decode(stored));
            return plain == null ? null : new String(plain, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** Guarda (null ou vazio apaga). */
    public void put(String key, String value) {
        Map<String, String> all = read();
        if (value == null || value.isEmpty()) {
            all.remove(key);
        } else {
            all.put(key, Base64.getEncoder().encodeToString(
                    Host.INSTANCE.protect(value.getBytes(StandardCharsets.UTF_8))));
        }
        write(all);
    }

    public void remove(String key) {
        put(key, null);
    }

    /** As chaves guardadas (para limpar o que sobrou de algo que o mod ja apagou). */
    public java.util.Set<String> keys() {
        return new java.util.TreeSet<>(read().keySet());
    }

    /** O cofre do sistema esta de verdade protegendo (Windows)? Falso: so embaralhado. */
    public static boolean isSystemProtected() {
        return Host.INSTANCE.secretsProtected();
    }

    private File file() {
        return new File(Host.INSTANCE.gameDir(), "config/" + id + ".secrets");
    }

    private Map<String, String> read() {
        return Host.INSTANCE.readStrings(file());
    }

    private void write(Map<String, String> all) {
        try {
            Host.INSTANCE.writeStrings(file(), all);
        } catch (Exception e) {
            Log.of(id).error("nao consegui gravar " + file().getName(), e);
        }
    }
}
