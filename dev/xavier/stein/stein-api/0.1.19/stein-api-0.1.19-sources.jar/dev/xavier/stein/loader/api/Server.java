package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/** O servidor em que o jogador esta, e entrar em outro. */
@Experimental(since = "0.1.16")
public final class Server {

    private Server() {
    }

    /**
     * O endereco do servidor de agora, do jeito que se compara: minusculo e sem a porta padrao ("mc.exemplo.com",
     * "1.2.3.4:25570"); "" fora de servidor (menu, mundo local). Vale tambem quando o jogo entrou pela linha de comando,
     * sem a lista de servidores.
     */
    public static String address() {
        return Host.INSTANCE.serverAddress();
    }

    /** O nome do servidor na lista de servidores, ou "". */
    public static String name() {
        return Host.INSTANCE.serverName();
    }

    /** Num servidor (e nao no menu nem num mundo local)? */
    public static boolean isMultiplayer() {
        return !address().isEmpty();
    }

    /** O ultimo servidor em que entrou nesta sessao ("" se nenhum): o que um "reconectar" usa. */
    public static String lastAddress() {
        return Host.INSTANCE.serverLast();
    }

    /**
     * O servidor da conexao em andamento ou da ultima tentada, mesmo que nao tenha entrado ("" se nenhuma): e o que
     * a tela de desconexao estava tentando, e para onde um "reconectar" volta.
     */
    public static String connectingAddress() {
        return Host.INSTANCE.serverConnecting();
    }

    /** Entra no servidor ("host" ou "host:porta"), como o botao da lista: sai do atual, se houver. */
    public static void connect(String address) {
        Host.INSTANCE.serverConnect(address);
    }
}
