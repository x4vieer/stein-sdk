package dev.xavier.stein.loader.api;

/**
 * Um mod do Stein Loader: recebe os eventos do jogo.
 *
 * <p>Registro por ServiceLoader: o jar do mod traz
 * META-INF/services/dev.xavier.stein.loader.api.SteinMod com o nome da classe, que precisa de um
 * construtor publico sem argumentos. Tipos do jogo chegam como Object (os nomes das
 * classes do jogo sao ofuscados; o mod faz o cast para os tipos que conhece).
 *
 * <p>Todos os metodos rodam na thread do jogo. Um erro num mod e registrado e o jogo
 * (e os outros mods) seguem.
 */
public interface SteinMod {

    /** Antes do Minecraft.startGame: o jogo existe, nada foi carregado (ex. registrar pacote de recursos). */
    default void beforeStartGame() {
    }

    /** Depois do startGame: janela, recursos e opcoes prontos (equivale ao FMLInitializationEvent). */
    default void afterStartGame() {
    }

    /** Fim de cada tick do cliente (TickEvent.ClientTickEvent, fase END). */
    default void onTickEnd() {
    }

    /** Depois de cada evento de teclado tratado pelo jogo (InputEvent.KeyInputEvent). */
    default void onKeyInput() {
    }

    /** Depois de cada evento de mouse tratado pelo jogo (InputEvent.MouseInputEvent). */
    default void onMouseInput() {
    }

    /** Depois do HUD (RenderGameOverlayEvent.Post, tipo ALL). */
    default void onOverlay(float partialTicks) {
    }

    /**
     * Depois de tudo, inclusive da grade da tela: o lugar do que tem de ficar por cima de qualquer elemento (a lista
     * do Tab). O {@link #onOverlay} desenha antes da grade, entao o que sai por ali fica embaixo dos elementos. A
     * profundidade comeca limpa aqui: nem os itens da grade, desenhados a frente, ficam por cima do que sai daqui.
     */
    default void onOverlayTop(float partialTicks) {
    }


    /** Antes da tela aberta se desenhar (GuiScreenEvent.DrawScreenEvent.Pre). */
    default void beforeDrawScreen(Object screen, int mouseX, int mouseY, float partialTicks) {
    }

    /** Depois da tela aberta se desenhar (GuiScreenEvent.DrawScreenEvent.Post). */
    default void afterDrawScreen(Object screen, int mouseX, int mouseY, float partialTicks) {
    }

    /**
     * Evento de mouse numa tela aberta, antes dela (GuiScreenEvent.MouseInputEvent.Pre).
     *
     * @return true para a tela nao receber o evento
     */
    default boolean onGuiMouseInput(Object screen) {
        return false;
    }

    /**
     * Mensagem de chat recebida do servidor, antes de ir para o chat
     * (ClientChatReceivedEvent, tipos 0 e 1).
     *
     * @return a mensagem (a mesma ou outra IChatComponent), ou null para descartar
     */
    default Object onChat(Object message) {
        return message;
    }

    /** Entrada num servidor ou mundo concluida (S01PacketJoinGame tratado). */
    default void onJoinGame() {
    }

    /**
     * Tela de configuracao do mod, aberta pelo botao Configurar do menu do Stein Loader.
     *
     * @param parent a tela para onde voltar ao fechar (GuiScreen)
     * @return a tela (GuiScreen), ou null se o mod nao tem; sem sobrescrever, o botao fica desligado
     */
    default Object configScreen(Object parent) {
        return null;
    }

    /**
     * O que o mod oferece ao jogador durante a partida: as opcoes e as telas dele na pagina do Painel (Shift
     * direito). Chamado toda vez que o Painel abre — descreva, nao guarde: os valores sao lidos na hora. Sem
     * sobrescrever, o mod nao aparece na lista do Painel.
     */
    default void onPage(Page page) {
    }

    /**
     * Tela do jogo montada (depois do initGui, e de novo quando a janela muda de tamanho),
     * como o InitGuiEvent.Post do Forge.
     *
     * @param screen a tela (GuiScreen)
     * @param buttons a lista de botoes dela (GuiButton): o mod pode acrescentar os seus, com ids
     *                longe dos do jogo
     */
    default void onGuiInit(Object screen, java.util.List<Object> buttons) {
    }

    /**
     * Botao clicado numa tela, antes do actionPerformed dela, como o
     * ActionPerformedEvent.Pre do Forge.
     *
     * @return true para ficar com o clique (a tela nao recebe)
     */
    default boolean onGuiAction(Object screen, Object button) {
        return false;
    }

    /**
     * Campo de visao do frame, depois das contas do jogo (EntityRenderer.getFOVModifier), como
     * o EntityViewRenderEvent.FOVModifier do Forge. Chamado mais de uma vez por frame: com
     * useFovSetting, o do mundo (parte da opcao de FOV do jogador); sem, o da mao (70). Os
     * mods recebem, em ordem, o valor devolvido pelo anterior.
     *
     * @return o campo de visao a usar, em graus
     */
    default float onFov(float fov, float partialTicks, boolean useFovSetting) {
        return fov;
    }

    /**
     * Fator de FOV do jogador — velocidade, correr, arco puxado
     * (AbstractClientPlayer.getFovModifier) —, que o jogo suaviza a cada tick; como o
     * FOVUpdateEvent do Forge.
     *
     * @return o fator a usar (1 = campo de visao da opcao, sem mudanca)
     */
    default float onFovModifier(float modifier) {
        return modifier;
    }

    /**
     * Antes de o atlas de blocos e itens (TextureMap) ser montado, a cada recarga de recursos
     * — o TextureStitchEvent.Pre do Forge: o mod registra texturas (TextureMap.registerSprite).
     * Textura com caminho em mcpatcher/ ou optifine/ vem de assets/&lt;dominio&gt;/&lt;caminho&gt;.png
     * (sem o textures/ na frente), como o OptiFine le. Pode vir antes do afterStartGame (a
     * primeira carga e dentro do startGame).
     */
    default void onTextureStitch(Object textureMap) {
    }

    /** Modelos e atlas prontos, a cada recarga de recursos (fim do ModelBakeEvent do Forge). */
    default void onModelsReloaded() {
    }

    /**
     * Modelo de cada item desenhado (ItemModelMesher.getItemModel): tela, mao, chao, moldura.
     * Chamado muitas vezes por frame — responder rapido para o item que nao e do mod. Os mods
     * recebem, em ordem, o modelo devolvido pelo anterior.
     *
     * @return o modelo (IBakedModel) a usar
     */
    default Object onItemModel(Object stack, Object model) {
        return model;
    }

    /**
     * Textura de uma peca de armadura vestida (LayerArmorBase; o
     * ForgeHooksClient.getArmorTexture do Forge): layer 1, ou 2 na calca; overlay null, ou o
     * nome da camada ("overlay", couro tingido).
     *
     * @return a ResourceLocation a usar
     */
    default Object onArmorTexture(Object stack, int layer, String overlay, Object location) {
        return location;
    }

    /**
     * Modelo de um bloco montado na geometria do chunk (BlockModelRenderer.renderModel), so para
     * os blocos marcados com {@link Game#watchBlockModel}: o mod troca o modelo daquela posicao
     * (texturas conectadas, por exemplo). Roda nas threads de montagem de chunk, varias ao mesmo
     * tempo: nada de estado mutavel compartilhado sem cuidado, nada de OpenGL. world e o acesso
     * aos blocos da montagem (IBlockAccess). Os mods recebem, em ordem, o modelo devolvido pelo
     * anterior.
     *
     * @return o modelo (IBakedModel) a usar
     */
    default Object onBlockModel(Object world, Object state, Object pos, Object model) {
        return model;
    }

    /**
     * Golpe do jogador numa entidade pelo clique (PlayerControllerMP.attackEntity no Minecraft.clickMouse), antes de
     * ir para o servidor — o AttackEntityEvent do Forge, no cliente. O braco ja balancou.
     *
     * @param target a entidade mirada (Entity)
     * @return true para cancelar o golpe (nada vai ao servidor)
     */
    default boolean onAttackEntity(Object target) {
        return false;
    }

    /**
     * Clique direito numa entidade (as duas interacoes do Minecraft.rightClickMouse), antes de ir para o servidor —
     * o EntityInteractEvent do Forge, no cliente. Golpes mandados por {@link Targeting#interact} nao passam aqui.
     *
     * <p>Cancelado, nada vai ao servidor e o clique segue como se nao houvesse entidade na mira: o item da mao e usado
     * (defender com a espada, comer, atirar), como no jogo quando se clica no ar.
     *
     * @param target a entidade mirada (Entity)
     * @return true para cancelar a interacao
     */
    @Experimental(since = "0.1.15")
    default boolean onInteractEntity(Object target) {
        return false;
    }

    /**
     * Clique num slot — PlayerControllerMP.windowClick, o caminho de todo clique de inventario do jogo e da
     * {@link Inventory} —, antes de ir para o servidor. Vale com o inventario aberto ou fechado (janela 0 e o do
     * proprio jogador).
     *
     * <p>Um clique pedido de dentro deste evento (responder a um clique com outro) vai direto ao jogo, sem voltar aos
     * mods.
     *
     * @param windowId a janela ({@link Inventory#windowId})
     * @param slot o slot da janela; {@link Inventory#OUTSIDE} e fora dela (larga o item do cursor)
     * @param button o botao (0 esquerdo, 1 direito; no {@link Inventory#SWAP}, o numero da hotbar 0-8)
     * @param mode o modo ({@link Inventory#PICKUP}, {@link Inventory#QUICK_MOVE}...)
     * @return true para cancelar: nada muda e nada vai ao servidor
     */
    @Experimental(since = "0.1.15")
    default boolean onWindowClick(int windowId, int slot, int button, int mode) {
        return false;
    }

    /**
     * O servidor mudou um slot (S2FPacketSetSlot), ja aplicado — resultado de um clique, de pegar um item do chao,
     * de o servidor mexer no inventario. Janela -1 e slot -1: o item no cursor.
     *
     * @param stack o item agora no slot (ItemStack), ou null se esvaziou
     */
    @Experimental(since = "0.1.15")
    default void onSlotChanged(int windowId, int slot, Object stack) {
    }

    /** O servidor mandou todos os itens de uma janela de uma vez (S30PacketWindowItems), ja aplicados: ao abrir um bau, ao entrar no mundo. */
    @Experimental(since = "0.1.15")
    default void onWindowItems(int windowId) {
    }

    /**
     * Uma entidade tomou dano — qualquer uma que o jogador ve, ele inclusive: o servidor avisa com o status 2
     * (S19PacketEntityStatus), e e esse aviso que faz a animacao vermelha, o balanco e o som de dano. Quanto foi,
     * {@link #onHealthChanged} diz (quando o servidor manda a vida).
     *
     * <p>Devolver true tira o <b>efeito</b> no cliente (sem vermelho, sem balanco, sem som) — o dano em si e do
     * servidor e continua. No proprio jogador, o balanco da camera vem da vida que baixou (S06), e nao daqui.
     *
     * @param entity quem tomou o dano (Entity)
     * @return true para nao mostrar o efeito
     */
    @Experimental(since = "0.1.15")
    default boolean onEntityHurt(Object entity) {
        return false;
    }

    /**
     * O jogo esta fechando: ultima chance de salvar o que ficou pendente (um {@link ModConfig#saveSoon} de um segundo
     * atras). Roda numa thread de encerramento, com o jogo ja se desmontando: grave arquivos e mais nada — nada de
     * desenho, rede ou tela. Tem de ser rapido.
     */
    @Experimental(since = "0.1.16")
    default void onShutdown() {
    }

    /**
     * Caiu a conexao com o servidor (ou a entrada foi recusada): a tela de desconexao acabou de abrir. {@code address}
     * e o servidor ({@link Server#connectingAddress}), {@code reason} o motivo como o jogo mostra, sem cores. Vem antes
     * do {@link #onGuiInit} dessa tela, uma vez por desconexao.
     */
    @Experimental(since = "0.1.16")
    default void onDisconnected(String address, String reason) {
    }

    /**
     * As relacoes mudaram ({@link Relations}: um cadastro, um fornecedor, uma cor), no fim do tick em que mudaram —
     * varias mudancas no mesmo tick chegam num aviso so. Quem guarda algo tirado das relacoes (cores de uma lista,
     * contagem de aliados) refaz aqui.
     */
    @Experimental(since = "0.1.16")
    default void onRelationsChanged() {
    }

    /** Uma entidade morreu (status 3 do S19PacketEntityStatus), antes da animacao de morte. */
    @Experimental(since = "0.1.15")
    default void onEntityDeath(Object entity) {
    }

    /**
     * A vida ou a absorcao (os coracoes amarelos) de uma entidade viva mudou, ja aplicada: a do jogador pelo
     * S06PacketUpdateHealth, a dos outros pelos dados que o servidor sincroniza (S1CPacketEntityMetadata). Dano e
     * {@code (oldHealth + oldAbsorption) - (newHealth + newAbsorption)}; negativo e cura.
     *
     * <p>Servidores podem esconder ou falsear a vida dos outros (muitos mandam sempre cheia): ai so o jogador tem
     * numeros de verdade, e {@link #onEntityHurt} continua valendo para todos. A absorcao dos outros so chega de
     * jogadores; de mobs ela nao e sincronizada.
     *
     * @param entity a entidade (EntityLivingBase)
     */
    @Experimental(since = "0.1.15")
    default void onHealthChanged(Object entity, float oldHealth, float newHealth, float oldAbsorption,
            float newAbsorption) {
    }

    /**
     * Esta entidade deve sumir da tela? Chamado para cada entidade de cada quadro, no lugar do desenho dela — tem de
     * responder rapido, sem alocar.
     *
     * <p>Nao e a invisibilidade do jogo: nada e desenhado, nem corpo, nem armadura, nem nome, nem sombra. Para quem
     * esta olhando, nao ha ninguem ali. A entidade continua existindo — e so a tela.
     *
     * @param entity a entidade prestes a ser desenhada (Entity)
     * @return true para nao desenhar
     */
    default boolean onHideEntity(Object entity) {
        return false;
    }

    /**
     * Esta entidade deve ser desenhada como <b>fantasma</b>? Chamado para cada entidade de cada quadro, no lugar do
     * desenho dela — tem de responder rapido, sem alocar.
     *
     * <p>E o mesmo fantasma que o jogo ja faz de quem esta invisivel e do seu time: a silhueta a 15% de opacidade,
     * sem escrever profundidade (por isso ela nao esconde o que esta atras). A diferenca e que a <b>armadura, o item
     * na mao e a capa tambem nao saem</b> — no jogo eles continuam solidos, e e por isso que invisivel de armadura
     * vira "armadura andando".
     *
     * <p>Quem esta escondido ({@link #onHideEntity}) nao chega aqui: sumir ganha de virar fantasma. O resto segue
     * igual — o nome continua acima da cabeca, e o golpe continua acertando. E so a tela.
     *
     * @param entity a entidade prestes a ser desenhada (Entity)
     * @return true para desenhar como fantasma
     */
    default boolean onGhostEntity(Object entity) {
        return false;
    }

    /**
     * A lista do Tab inteira, no lugar da do jogo: o mod desenha a dele (ping, filtros, quantos jogadores mostrar).
     * Chamado a cada quadro com o Tab aberto — responder rapido. O primeiro mod que desenhar encerra.
     *
     * @param overlay o GuiPlayerTabOverlay do jogo, para o que so ele sabe (o nome formatado, as barras de ping)
     * @param width largura da tela, em pixels de GUI
     * @param scoreboard o Scoreboard; objective o ScoreObjective da lista, ou null
     * @return true quando o mod desenhou: o jogo nao desenha a dele
     */
    default boolean onPlayerList(Object overlay, int width, Object scoreboard, Object objective) {
        return false;
    }

    /**
     * Nome de um jogador na lista do Tab (GuiPlayerTabOverlay.getPlayerName: com o prefixo e o sufixo do time do
     * servidor). Chamado a cada quadro com o Tab aberto — responder rapido. Os mods recebem, em ordem, o nome devolvido
     * pelo anterior.
     *
     * @param playerInfo o jogador na lista (NetworkPlayerInfo)
     * @return o nome a mostrar
     */
    default String onPlayerListName(Object playerInfo, String name) {
        return name;
    }

    /**
     * Nome acima da cabeca de uma entidade viva (RendererLivingEntity.renderName: o getDisplayName, com o time do
     * servidor). Chamado a cada quadro por entidade com nome visivel. Os mods recebem, em ordem, o nome devolvido pelo
     * anterior.
     *
     * @param entity a entidade (EntityLivingBase)
     * @param name o nome (IChatComponent)
     * @return o nome a mostrar (IChatComponent)
     */
    default Object onNametag(Object entity, Object name) {
        return name;
    }

    /**
     * O mundo acabou de ser desenhado — blocos, entidades, particulas e a camada translucida —, antes das nuvens de
     * cima e da mao: o lugar de desenhar no mundo (caixas, linhas, marcadores), como o RenderWorldLastEvent do Forge.
     * A matriz e a da camera, com a origem no olho do jogador: some a posicao interpolada da entidade da camera ao que
     * voce quer desenhar num lugar do mundo. Uma vez por quadro. Deixe o estado de GL como achou.
     */
    @Experimental(since = "0.1.14")
    default void onRenderWorld(float partialTicks) {
    }

    /**
     * Pacote de plugin do servidor (S3FPacketCustomPayload), ja na thread do jogo: o canal ("MC|Brand", "BungeeCord",
     * o do seu plugin) e uma copia dos bytes, que o mod pode guardar. O jogo trata o pacote do mesmo jeito depois (e
     * ignora canal que nao conhece). Para mandar um ao servidor: {@link Net#sendPayload}.
     */
    @Experimental(since = "0.1.14")
    default void onCustomPayload(String channel, byte[] data) {
    }

    /**
     * O que o jogador vai mandar — mensagem de chat ou comando ("/..."), antes de sair para o servidor: e o lugar de
     * um comando so do cliente, como o ClientChatEvent do Forge. Os mods recebem, em ordem, a mensagem devolvida pelo
     * anterior.
     *
     * @return a mensagem a mandar (a mesma ou outra), ou null para nao mandar nada
     */
    @Experimental(since = "0.1.14")
    default String onSendChat(String message) {
        return message;
    }

    /**
     * Um som prestes a tocar (ISound), como o PlaySoundEvent do Forge: trocar por outro, ou calar. Chamado a cada
     * som — responder rapido. Os mods recebem, em ordem, o som devolvido pelo anterior.
     *
     * @return o som a tocar (ISound, o mesmo ou outro), ou null para nao tocar
     */
    @Experimental(since = "0.1.14")
    default Object onPlaySound(Object sound) {
        return sound;
    }
}
