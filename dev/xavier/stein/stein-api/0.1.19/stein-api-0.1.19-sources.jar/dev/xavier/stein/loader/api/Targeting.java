package dev.xavier.stein.loader.api;

import java.util.Collections;
import java.util.List;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Mira e golpe: quem esta na linha da mira, e o golpe mandado pelo mod.
 *
 * <p>As pecas se combinam. <b>Proteger</b> uma entidade: cancelar em {@link SteinMod#onAttackEntity} (e
 * {@link SteinMod#onInteractEntity}). <b>Golpe que atravessa</b>: cancelar o golpe no aliado, olhar o
 * {@link #raycast()} e mandar {@link #attack} no primeiro da fila que nao e aliado. O golpe daqui e o do jogo
 * ({@code PlayerControllerMP.attackEntity}): o servidor recebe o mesmo pacote de um clique, e confere o alcance.
 *
 * <p>Chame da thread do jogo.
 */
@Experimental(since = "0.1.15")
public final class Targeting {

    private Targeting() {
    }

    /** Uma entidade atravessada pelo raio da mira. */
    public static final class Hit {
        /** A entidade (Entity). */
        public final Object entity;
        /** Distancia do olho ate onde o raio entra na caixa dela; 0 se o olho esta dentro da caixa. */
        public final double distance;
        /** Onde o raio entra na caixa (o olho, se esta dentro dela). */
        public final double x;
        public final double y;
        public final double z;

        public Hit(Object entity, double distance, double x, double y, double z) {
            this.entity = entity;
            this.distance = distance;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    /** O resultado de um {@link #raycast}. */
    public static final class Ray {
        /** As entidades no raio, da mais perto para a mais longe (lista que nao muda). */
        public final List<Hit> hits;
        /**
         * Distancia ate o primeiro bloco que o raio acerta, ou {@link Double#POSITIVE_INFINITY} se nenhum dentro do
         * alcance. No jogo, a entidade atras de um bloco nao e mirada: compare {@code hit.distance < blockDistance}.
         */
        public final double blockDistance;
        /** O alcance usado. */
        public final double reach;

        /** O bloco que parou o raio ({@code "minecraft:stone"}), ou null se nenhum parou dentro do alcance. */
        @Experimental(since = "0.1.16")
        public final String blockId;
        /** Onde esta esse bloco (valem so com {@link #blockId} != null). */
        @Experimental(since = "0.1.16")
        public final int blockX;
        @Experimental(since = "0.1.16")
        public final int blockY;
        @Experimental(since = "0.1.16")
        public final int blockZ;

        public Ray(List<Hit> hits, double blockDistance, double reach) {
            this(hits, blockDistance, reach, null, 0, 0, 0);
        }

        @Experimental(since = "0.1.16")
        public Ray(List<Hit> hits, double blockDistance, double reach, String blockId, int blockX, int blockY,
                int blockZ) {
            this.hits = Collections.unmodifiableList(hits);
            this.blockDistance = blockDistance;
            this.reach = reach;
            this.blockId = blockId;
            this.blockX = blockX;
            this.blockY = blockY;
            this.blockZ = blockZ;
        }

        /** A primeira entidade antes de qualquer bloco, ou null. */
        public Hit first() {
            return hits.isEmpty() || hits.get(0).distance >= blockDistance ? null : hits.get(0);
        }
    }

    /**
     * Quais blocos o raio atravessa em vez de parar. Recebe o id do bloco ({@code "minecraft:leaves"}); combine com
     * {@link #or}. Blocos sem colisao (flor, grama alta, trepadeira) e liquidos nunca param o raio, como no jogo.
     */
    @Experimental(since = "0.1.16")
    @FunctionalInterface
    public interface BlockFilter {
        boolean passes(String blockId);

        default BlockFilter or(BlockFilter other) {
            return id -> passes(id) || other.passes(id);
        }
    }

    /** Folhagem: folhas, arbustos, plantas, cogumelos e vitoria-regia — o que so atrapalha a vista. */
    @Experimental(since = "0.1.16")
    public static final BlockFilter FOLIAGE = ids("leaves", "leaves2", "tallgrass", "deadbush", "yellow_flower",
            "red_flower", "double_plant", "sapling", "vine", "brown_mushroom", "red_mushroom", "waterlily", "wheat",
            "carrots", "potatoes", "nether_wart", "reeds", "melon_stem", "pumpkin_stem", "web");

    /** Vidro: blocos, paineis e as versoes coloridas. */
    @Experimental(since = "0.1.16")
    public static final BlockFilter GLASS = ids("glass", "stained_glass", "glass_pane", "stained_glass_pane");

    /** Um filtro pelos ids (com ou sem o "minecraft:"). */
    @Experimental(since = "0.1.16")
    public static BlockFilter ids(String... ids) {
        java.util.Set<String> set = new java.util.HashSet<>();
        for (String id : ids) {
            set.add(id.indexOf(58) >= 0 ? id : "minecraft:" + id);
        }
        return set::contains;
    }

    /**
     * Uma busca na linha da mira com opcoes, para {@link #raycast(Query)}. Sem mexer em nada, e o
     * {@link #raycast(double)} com o alcance de golpe.
     *
     * <pre>
     * Targeting.Hit alvo = Targeting.raycast(Targeting.query()
     *         .reach(32).living().margin(0.3).passThrough(Targeting.FOLIAGE)).first();
     * </pre>
     */
    @Experimental(since = "0.1.16")
    public static final class Query {
        /** Alcance em blocos a partir do olho; NaN = o de golpe do jogo. */
        public double reach = Double.NaN;
        /** So entidades vivas (jogador, mob, animal) e que nao morreram. */
        public boolean living;
        /** Sem as invisiveis. */
        public boolean visibleOnly;
        /** Caixa de cada entidade aumentada nisso de cada lado; NaN = a borda de colisao do jogo (0,1). */
        public double margin = Double.NaN;
        /** Blocos que o raio atravessa; null = nenhum. */
        public BlockFilter passThrough;
        /** Tira da lista quem esta atras do bloco que parou o raio. */
        public boolean cutAtBlock;
        /** Nunca entram (a camera e sempre fora). */
        public final List<Object> excluded = new java.util.ArrayList<>();

        public Query reach(double blocks) {
            reach = blocks;
            return this;
        }

        public Query living() {
            living = true;
            return this;
        }

        public Query visibleOnly() {
            visibleOnly = true;
            return this;
        }

        public Query margin(double blocks) {
            margin = blocks;
            return this;
        }

        public Query passThrough(BlockFilter filter) {
            passThrough = passThrough == null ? filter : passThrough.or(filter);
            return this;
        }

        public Query cutAtBlock() {
            cutAtBlock = true;
            return this;
        }

        public Query exclude(Object entity) {
            if (entity != null) {
                excluded.add(entity);
            }
            return this;
        }
    }

    /** Uma busca nova, com o padrao do jogo. */
    @Experimental(since = "0.1.16")
    public static Query query() {
        return new Query();
    }

    /**
     * Todas as entidades na linha da mira ate {@code reach} blocos do olho, em ordem de distancia — as mesmas que o
     * jogo consideraria para mirar (as que colidem, sem espectador; a caixa de cada uma com a borda de colisao), na
     * posicao interpolada do quadro. Blocos nao cortam a lista: veja {@link Ray#blockDistance}.
     */
    public static Ray raycast(double reach) {
        return Host.INSTANCE.raycast(reach);
    }

    /**
     * A busca com opcoes ({@link Query}): so vivos, caixa maior para alvo distante, blocos que nao param o raio. O raio
     * anda bloco a bloco, e cada bloco com colisao e testado pela forma dele (laje, escada, cerca), como no jogo.
     */
    @Experimental(since = "0.1.16")
    public static Ray raycast(Query query) {
        return Host.INSTANCE.raycastQuery(query);
    }

    /** {@link #raycast(double)} com o alcance de golpe do jogo ({@link #attackReach}). */
    public static Ray raycast() {
        return raycast(attackReach());
    }

    /** O alcance de golpe em entidade do jogo: 3 blocos, 6 no criativo. */
    public static double attackReach() {
        return Host.INSTANCE.attackReach();
    }

    /** A entidade que o jogo esta mirando agora (o objectMouseOver), ou null. */
    public static Object pointedEntity() {
        return Host.INSTANCE.pointedEntity();
    }

    /**
     * Golpeia a entidade como o clique do jogo, sem balancar o braco ({@link #swing}) — o clique faz os dois. Nao passa
     * por {@link SteinMod#onAttackEntity}: e para quem cancelou um golpe la e manda outro.
     *
     * @return false sem jogador ou sem entidade
     */
    public static boolean attack(Object entity) {
        return Host.INSTANCE.attack(entity);
    }

    /** Balanca o braco do jogador (o servidor ve a animacao), como o clique faz antes do golpe. */
    public static void swing() {
        Host.INSTANCE.swing();
    }

    /**
     * Interage com a entidade como o clique direito do jogo (montar, negociar...). Nao passa por
     * {@link SteinMod#onInteractEntity}.
     *
     * @return o que o jogo devolve: true se a interacao aconteceu
     */
    public static boolean interact(Object entity) {
        return Host.INSTANCE.interact(entity);
    }
}
