package dev.xavier.stein.loader.api;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Trabalho fora da thread do jogo, e a volta para ela. O jogo so pode ser mexido da thread dele (a do desenho e dos
 * ticks); um download, uma leitura de disco ou uma conta pesada vao para {@link #async}, e o resultado volta na thread
 * do jogo, pronto para usar — sem cada mod abrir as proprias threads e passar o resultado por campos volateis.
 */
@Experimental(since = "0.1.16")
public final class Tasks {

    private static final AtomicInteger COUNT = new AtomicInteger();
    /** Poucas threads para todos os mods: trabalho de fundo nao pode competir com o jogo. */
    private static final ExecutorService POOL = new ThreadPoolExecutor(0, 4, 30, TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(), r -> {
                Thread t = new Thread(r, "stein-mods-" + COUNT.incrementAndGet());
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            });

    private Tasks() {
    }

    /** Roda na thread do jogo, no fim do tick corrente (ou no proximo, se chamado de la). */
    public static void onGameThread(Runnable task) {
        Host.INSTANCE.onGameThread(task);
    }

    /** Roda na thread do jogo daqui a {@code ticks} ticks (20 por segundo). */
    public static void later(int ticks, Runnable task) {
        Host.INSTANCE.later(Math.max(0, ticks), task);
    }

    /**
     * Roda {@code work} numa thread de fundo; o resultado (ou o erro) volta na thread do jogo.
     *
     * @param onError pode ser null: o erro vai para o log do jogo
     */
    public static <T> void async(Callable<T> work, Consumer<T> onResult, Consumer<Throwable> onError) {
        POOL.execute(() -> {
            T value;
            try {
                value = work.call();
            } catch (Throwable e) {
                onGameThread(() -> {
                    if (onError != null) {
                        onError.accept(e);
                    } else {
                        Host.INSTANCE.log("tasks", 2, "tarefa de fundo falhou", e);
                    }
                });
                return;
            }
            onGameThread(() -> onResult.accept(value));
        });
    }

    /** Roda {@code work} numa thread de fundo, sem volta. */
    public static void background(Runnable work) {
        POOL.execute(work);
    }
}
