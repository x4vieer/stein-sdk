package dev.xavier.stein.loader.api;

import dev.xavier.stein.loader.api.spi.Host;

/**
 * Os blocos do mundo carregado no cliente, para mapas e radares: altura, o que tem em cada lugar, luz e a cor de cada
 * bloco como um minimapa pinta. So o que o servidor mandou: chunk que nao chegou da "nada" (ar, altura 0). Chame da
 * thread do jogo.
 *
 * <pre>
 * if (Terrain.isLoaded(x &gt;&gt; 4, z &gt;&gt; 4)) {
 *     int y = Terrain.height(x, z) - 1;
 *     int argb = Terrain.color(x, y, z);   // a textura do bloco com a tinta do bioma
 * }
 * </pre>
 */
@Experimental(since = "0.1.16")
public final class Terrain {

    /** Recebe cada posicao de uma busca ({@link #forEachSpawner}). */
    @FunctionalInterface
    public interface Visitor {
        void at(int x, int y, int z);
    }

    private Terrain() {
    }

    /** O mundo de agora (tipo do jogo), ou null fora dele: compare para saber se o jogador trocou de mundo. */
    public static Object current() {
        return Host.INSTANCE.terrainWorld();
    }

    /** O chunk (x e z de chunk, bloco &gt;&gt; 4) chegou e tem blocos? */
    public static boolean isLoaded(int chunkX, int chunkZ) {
        return Host.INSTANCE.terrainLoaded(chunkX, chunkZ);
    }

    /**
     * A altura da coluna: o primeiro y acima do bloco mais alto que para a luz do ceu (o mapa de altura do jogo — flor,
     * neve fina e vidro nao contam). 0 sem chunk.
     */
    public static int height(int x, int z) {
        return Host.INSTANCE.terrainHeight(x, z);
    }

    public static boolean isAir(int x, int y, int z) {
        return Host.INSTANCE.terrainAir(x, y, z);
    }

    /** O id do bloco ({@code "minecraft:leaves"}; {@code "minecraft:air"} sem bloco ou sem chunk). */
    public static String blockId(int x, int y, int z) {
        return Host.INSTANCE.terrainBlockId(x, y, z);
    }

    /** Material solido (pedra, madeira, vidro; nao planta, neve fina nem liquido). */
    public static boolean isSolid(int x, int y, int z) {
        return Host.INSTANCE.terrainSolid(x, y, z);
    }

    public static boolean isWater(int x, int y, int z) {
        return Host.INSTANCE.terrainWater(x, y, z);
    }

    /**
     * A cor do bloco como um minimapa detalhado pinta (ARGB opaca): a media da textura de cima, tingida pelo bioma
     * onde o jogo tinge (grama, folhas, agua). Recalculada sozinha quando o pacote de texturas muda.
     */
    public static int color(int x, int y, int z) {
        return Host.INSTANCE.terrainColor(x, y, z);
    }

    /** A cor do item mapa do jogo para o bloco (so a do material, sem textura nem bioma), ARGB opaca. */
    public static int mapColor(int x, int y, int z) {
        return Host.INSTANCE.terrainMapColor(x, y, z);
    }

    /** A luz do ceu que chega ali (0 a 15): pouca luz em volta do jogador quer dizer caverna. */
    public static int skyLight(int x, int y, int z) {
        return Host.INSTANCE.terrainSkyLight(x, y, z);
    }

    /** O mundo tem ceu? (O Nether nao tem.) */
    public static boolean hasSky() {
        return Host.INSTANCE.terrainHasSky();
    }

    /** Cada gaiola de monstros (spawner) carregada. */
    public static void forEachSpawner(Visitor visitor) {
        Host.INSTANCE.terrainSpawners(visitor);
    }
}
