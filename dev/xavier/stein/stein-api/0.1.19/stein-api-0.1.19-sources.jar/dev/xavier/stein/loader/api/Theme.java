package dev.xavier.stein.loader.api;

/**
 * As cores do design system do Stein (ARGB), as mesmas do Stein Client e das telas do Loader: o mod que desenha a
 * propria tela ou o proprio elemento de HUD usa estas, e fica com a cara do resto. A pagina do mod no Painel ja sai
 * com elas sozinha.
 */
@Experimental(since = "0.1.18")
public final class Theme {

    /** O campo: violeta quase preto (o fundo de cartoes e paineis). */
    public static final int BACKGROUND = 0xFF0A0614;
    /** A tinta: o texto principal. */
    public static final int INK = 0xFFE8E1F5;
    /** Texto secundario e texto apagado. */
    public static final int MUTED = 0x8CE8E1F5;
    public static final int FAINT = 0x59E8E1F5;
    /** Dourado-violeta: numeros, versoes, marcas. */
    public static final int GOLD = 0xFFB89CD9;
    /** Violeta eletrico: ligado, selecionado, a acao principal. */
    public static final int ACCENT = 0xFF7C4DFF;
    /** O acento bem fraco: o fundo do que esta selecionado ou sob o cursor. */
    public static final int ACCENT_SOFT = 0x247C4DFF;
    /** Os fios (bordas e divisores de um pixel). */
    public static final int RULE = 0x1AE8E1F5;
    public static final int RULE_STRONG = 0x38E8E1F5;
    /** Erro, atencao, e o que deu certo. */
    public static final int DANGER = 0xFFE0708A;
    public static final int WARN = 0xFFE0B870;
    public static final int OK = 0xFF9BD4A8;

    private Theme() {
    }
}
