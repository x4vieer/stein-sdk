package dev.xavier.stein.loader.api;

/**
 * As fontes do design system do Stein, as mesmas do Stein Client e das telas do Loader, para o mod desenhar no mesmo
 * padrao ({@link Render#text(String, float, float, int, Typeface, float)}).
 *
 * <ul>
 *   <li>{@link #TITLE}: titulos (Cinzel);
 *   <li>{@link #TEXT}: nomes, descricoes e texto corrido (EB Garamond); {@link #ITALIC}, o mesmo em italico;
 *   <li>{@link #MONO}: numeros, versoes, ids e rotulos em caixa alta (JetBrains Mono).
 * </ul>
 */
@Experimental(since = "0.1.18")
public enum Typeface {
    TITLE, TEXT, ITALIC, MONO
}
