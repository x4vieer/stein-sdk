package dev.xavier.stein.gradle;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.file.RegularFileProperty;
import org.gradle.api.logging.Logger;
import org.gradle.api.logging.Logging;
import org.gradle.api.provider.ValueSource;
import org.gradle.api.provider.ValueSourceParameters;
import org.gradle.process.ExecOperations;

/**
 * Os jars para compilar o mod, pedidos ao SDK ("stein-sdk.jar classpath &lt;projeto&gt;"). E um ValueSource porque e
 * lido quando o Gradle monta o classpath (ou quando a IDE importa o projeto), antes de qualquer tarefa: o Gradle so
 * aceita processo externo nessa hora por aqui.
 *
 * <p>Se o setup ainda nao foi feito, e feito aqui — e o que deixa a IDE importar o projeto de primeira, sem rodar o
 * steinSetup antes. Leva um tempo na primeira vez (baixa os mapeamentos do MCP), e so.
 */
public abstract class SdkClasspath implements ValueSource<ArrayList<File>, SdkClasspath.Params> {

    public interface Params extends ValueSourceParameters {
        RegularFileProperty getSdkJar();

        RegularFileProperty getJavaExecutable();

        DirectoryProperty getSdkHome();

        DirectoryProperty getMinecraftDir();

        DirectoryProperty getProjectDir();
    }

    @Inject
    protected abstract ExecOperations getExec();

    @Override
    public ArrayList<File> obtain() {
        Params p = getParameters();
        File home = p.getSdkHome().get().getAsFile();
        File jar = p.getSdkJar().get().getAsFile();
        File java = p.getJavaExecutable().get().getAsFile();
        Logger log = Logging.getLogger(SdkClasspath.class);
        if (!SdkTool.setupDone(home).isFile()) {
            log.lifecycle("Stein SDK: preparing Minecraft " + SdkTool.MC_VERSION + " for compiling (once per machine)...");
            List<String> args = new ArrayList<>(List.of("setup"));
            if (p.getMinecraftDir().isPresent()) {
                args.add("--mc");
                args.add(p.getMinecraftDir().get().getAsFile().getAbsolutePath());
            }
            SdkTool.run(getExec(), java, jar, home, args, log);
        }
        String out = SdkTool.run(getExec(), java, jar, home,
                List.of("classpath", p.getProjectDir().get().getAsFile().getAbsolutePath()), null);
        return new ArrayList<>(SdkTool.jars(out));
    }
}
