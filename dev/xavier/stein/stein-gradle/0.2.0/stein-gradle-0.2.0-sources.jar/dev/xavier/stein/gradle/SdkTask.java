package dev.xavier.stein.gradle;

import java.io.File;
import java.util.List;

import javax.inject.Inject;

import org.gradle.api.DefaultTask;
import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.file.RegularFileProperty;
import org.gradle.api.tasks.InputFile;
import org.gradle.api.tasks.Internal;
import org.gradle.api.tasks.PathSensitive;
import org.gradle.api.tasks.PathSensitivity;
import org.gradle.process.ExecOperations;

/** Tarefa que roda o stein-sdk.jar: o jar, o Java 25 que o roda e a pasta de trabalho do SDK. */
public abstract class SdkTask extends DefaultTask {

    /** O stein-sdk.jar (baixado ou o de {@code stein.sdkJar}): trocar de SDK refaz o .steinmod. */
    @InputFile
    @PathSensitive(PathSensitivity.NONE)
    public abstract RegularFileProperty getSdkJar();

    /** O java do toolchain do projeto (25): o SDK nao roda num Java mais velho. */
    @Internal
    public abstract RegularFileProperty getJavaExecutable();

    @Internal
    public abstract DirectoryProperty getSdkHome();

    @Inject
    protected abstract ExecOperations getExec();

    /** Roda o SDK com args e mostra o que ele imprimiu. */
    protected String sdk(List<String> args) {
        File java = getJavaExecutable().get().getAsFile();
        return SdkTool.run(getExec(), java, getSdkJar().get().getAsFile(), getSdkHome().get().getAsFile(), args,
                getLogger());
    }
}
