package dev.xavier.stein.gradle;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.gradle.api.GradleException;
import org.gradle.api.logging.Logger;
import org.gradle.api.logging.Logging;
import org.gradle.process.ExecOperations;

/**
 * O stein-sdk.jar visto do Gradle: onde ele fica, como se baixa e como se roda.
 *
 * <p>O plugin nao repete nada do SDK: nem mapeamentos, nem a traducao de nomes, nem a conferencia. Roda o jar (com o
 * Java 25 do toolchain) e le o que ele imprime — assim o "gradlew build" e o "java -jar stein-sdk.jar build" dao o
 * mesmo .steinmod.
 */
final class SdkTool {

    static final String MC_VERSION = "1.8.9";
    private static final String RELEASES = "https://github.com/x4vieer/stein-sdk/releases/download/v";

    private SdkTool() {
    }

    /** A versao do proprio plugin, que e a do SDK que ele usa se o projeto nao disser outra. */
    static String pluginVersion() {
        try (InputStream in = SdkTool.class.getResourceAsStream("version.txt")) {
            return in == null ? "0.2.0" : new String(in.readAllBytes(), StandardCharsets.UTF_8).trim();
        } catch (IOException e) {
            return "0.2.0";
        }
    }

    /**
     * O stein-sdk.jar da versao pedida, no cache do Gradle (&lt;gradle home&gt;/caches/stein-sdk/&lt;versao&gt;).
     * Baixa uma vez; o arquivo so entra no cache inteiro (baixa ao lado e troca), entao dois builds juntos nao se
     * atrapalham.
     */
    static File download(File gradleHome, String version, boolean offline) {
        Path target = gradleHome.toPath().resolve("caches/stein-sdk/" + version + "/stein-sdk.jar");
        if (Files.isRegularFile(target)) {
            return target.toFile();
        }
        String url = RELEASES + version + "/stein-sdk.jar";
        if (offline) {
            throw new GradleException("Stein SDK " + version + " is not in the Gradle cache and Gradle is offline ("
                    + url + ")");
        }
        try {
            Files.createDirectories(target.getParent());
            HttpClient http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).build();
            HttpResponse<byte[]> r = http.send(HttpRequest.newBuilder(URI.create(url)).build(),
                    HttpResponse.BodyHandlers.ofByteArray());
            byte[] body = r.body();
            // Um jar comeca por "PK": pagina de erro nao entra no cache.
            if (r.statusCode() != 200 || body.length < 4 || body[0] != 'P' || body[1] != 'K') {
                throw new GradleException("could not download Stein SDK " + version + " (HTTP " + r.statusCode()
                        + "): " + url);
            }
            Path tmp = Files.createTempFile(target.getParent(), "stein-sdk", ".part");
            Files.write(tmp, body);
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            return target.toFile();
        } catch (IOException e) {
            throw new GradleException("could not download Stein SDK " + version + ": " + url, e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new GradleException("interrupted while downloading " + url, e);
        }
    }

    /** A pasta de trabalho do SDK, como o proprio SDK a acha: STEIN_SDK_HOME, ou ~/.stein-sdk. */
    static File defaultHome() {
        String env = System.getenv("STEIN_SDK_HOME");
        return env != null && !env.isBlank() ? new File(env) : new File(System.getProperty("user.home"), ".stein-sdk");
    }

    /** O arquivo que o setup deixa por ultimo: com ele, o jogo ja esta montado. */
    static File setupDone(File home) {
        return new File(home, MC_VERSION + "/libraries.txt");
    }

    /** O .minecraft de sempre, o mesmo que o SDK usa. */
    static File defaultMinecraft() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String user = System.getProperty("user.home");
        if (os.contains("win")) {
            String appdata = System.getenv("APPDATA");
            return Paths.get(appdata != null ? appdata : user, ".minecraft").toFile();
        }
        if (os.contains("mac")) {
            return Paths.get(user, "Library", "Application Support", "minecraft").toFile();
        }
        return Paths.get(user, ".minecraft").toFile();
    }

    /** O nome do .steinmod, pela mesma regra do SDK: o "name" (ou o "id") sem espacos nem simbolos. */
    static String modFileName(File steinmodJson, String fallback) {
        if (steinmodJson == null || !steinmodJson.isFile()) {
            return fallback + ".steinmod";
        }
        String json;
        try {
            json = Files.readString(steinmodJson.toPath());
        } catch (IOException e) {
            return fallback + ".steinmod";
        }
        String name = field(json, "name");
        String id = field(json, "id");
        String base = (name.isEmpty() ? id : name).replaceAll("[^A-Za-z0-9._-]", "");
        return (base.isEmpty() ? fallback : base) + ".steinmod";
    }

    private static String field(String json, String key) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
        return m.find() ? m.group(1) : "";
    }

    /**
     * Roda "java -jar stein-sdk.jar args..." e devolve o que ele imprimiu. O que sai no erro vai para o erro do
     * Gradle; o que sai na saida, com um {@code log}, tambem vai para o console.
     */
    static String run(ExecOperations exec, File java, File sdkJar, File home, List<String> args, Logger log) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        List<String> cmd = new ArrayList<>(List.of("-jar", sdkJar.getAbsolutePath()));
        cmd.addAll(args);
        var result = exec.exec(spec -> {
            spec.setExecutable(java.getAbsolutePath());
            spec.setArgs(cmd);
            spec.environment("STEIN_SDK_HOME", home.getAbsolutePath());
            spec.setStandardOutput(out);
            spec.setErrorOutput(err);
            spec.setIgnoreExitValue(true);
        });
        String stdout = out.toString(StandardCharsets.UTF_8);
        String stderr = err.toString(StandardCharsets.UTF_8);
        if (log != null && !stdout.isBlank()) {
            // As linhas recuadas sao listas (os jars do classpath no fim do setup): so com --info.
            stdout.lines().forEach(l -> {
                if (l.startsWith("  ")) {
                    log.info(l);
                } else {
                    log.lifecycle(l);
                }
            });
        }
        if (result.getExitValue() != 0) {
            throw new GradleException("stein-sdk " + String.join(" ", args) + " failed:\n" + stderr.strip());
        }
        if (!stderr.isBlank()) {
            Logger warn = log != null ? log : Logging.getLogger(SdkTool.class);
            stderr.lines().forEach(warn::warn);
        }
        return stdout;
    }

    /** As linhas da saida que sao jars que existem: o que o "classpath" imprime (e nada das mensagens). */
    static List<File> jars(String output) {
        List<File> out = new ArrayList<>();
        for (String line : output.split("\\R")) {
            String l = line.strip();
            if (l.endsWith(".jar") && new File(l).isFile()) {
                out.add(new File(l));
            }
        }
        return out;
    }
}
