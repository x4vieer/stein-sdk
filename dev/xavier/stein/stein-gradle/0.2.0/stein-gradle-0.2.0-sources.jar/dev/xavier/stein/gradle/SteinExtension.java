package dev.xavier.stein.gradle;

import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.file.RegularFileProperty;
import org.gradle.api.provider.Property;

/**
 * O bloco {@code stein { }} do build.gradle do mod.
 *
 * <pre>
 *   stein {
 *       sdkVersion = "0.2.0"                      // a release do stein-sdk.jar (padrao: a versao do plugin)
 *       minecraftDir = file("D:/Games/.minecraft") // se o .minecraft nao estiver no lugar de sempre
 *       sdkJar = file("../stein-sdk.jar")         // um stein-sdk.jar local em vez do baixado (testes)
 *   }
 * </pre>
 */
public abstract class SteinExtension {

    /** A versao do stein-sdk.jar, baixado de github.com/x4vieer/stein-sdk/releases/download/v&lt;versao&gt;. */
    public abstract Property<String> getSdkVersion();

    /** O .minecraft: de onde o setup tira o jogo, e para onde o installMod copia. */
    public abstract DirectoryProperty getMinecraftDir();

    /** Um stein-sdk.jar local; com ele nada se baixa (tambem -Pstein.sdkJar=caminho). */
    public abstract RegularFileProperty getSdkJar();

    /** A pasta de trabalho do SDK (padrao: STEIN_SDK_HOME ou ~/.stein-sdk), onde o setup monta o jogo. */
    public abstract DirectoryProperty getSdkHome();
}
