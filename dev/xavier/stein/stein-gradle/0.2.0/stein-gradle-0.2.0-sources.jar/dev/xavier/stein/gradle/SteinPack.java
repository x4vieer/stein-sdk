package dev.xavier.stein.gradle;

import java.util.List;

import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.file.RegularFileProperty;
import org.gradle.api.tasks.InputDirectory;
import org.gradle.api.tasks.OutputFile;
import org.gradle.api.tasks.PathSensitive;
import org.gradle.api.tasks.PathSensitivity;
import org.gradle.api.tasks.TaskAction;

/**
 * {@code steinmod}: "java -jar stein-sdk.jar pack" sobre o que o Gradle compilou — traduz os nomes para os do jogo,
 * confere cada referencia ao jogo e empacota com os recursos em build/libs/&lt;Nome&gt;.steinmod.
 */
public abstract class SteinPack extends SdkTask {

    @InputDirectory
    @PathSensitive(PathSensitivity.RELATIVE)
    public abstract DirectoryProperty getClassesDir();

    @InputDirectory
    @PathSensitive(PathSensitivity.RELATIVE)
    public abstract DirectoryProperty getResourcesDir();

    @OutputFile
    public abstract RegularFileProperty getOutputFile();

    public SteinPack() {
        setGroup("stein");
        setDescription("Translates, checks and packs the compiled mod into build/libs/<Name>.steinmod.");
    }

    @TaskAction
    public void pack() {
        sdk(List.of("pack", getClassesDir().get().getAsFile().getAbsolutePath(),
                getResourcesDir().get().getAsFile().getAbsolutePath(),
                getOutputFile().get().getAsFile().getAbsolutePath()));
    }
}
