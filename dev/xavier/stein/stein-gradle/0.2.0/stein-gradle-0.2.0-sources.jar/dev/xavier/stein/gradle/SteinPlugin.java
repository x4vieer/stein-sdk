package dev.xavier.stein.gradle;

import java.io.File;
import java.util.List;
import java.util.concurrent.Callable;

import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.file.ConfigurableFileCollection;
import org.gradle.api.file.Directory;
import org.gradle.api.file.FileCollection;
import org.gradle.api.file.RegularFile;
import org.gradle.api.plugins.JavaPlugin;
import org.gradle.api.plugins.JavaPluginExtension;
import org.gradle.api.provider.Provider;
import org.gradle.api.provider.ProviderFactory;
import org.gradle.api.tasks.Copy;
import org.gradle.api.tasks.SourceSet;
import org.gradle.api.tasks.TaskProvider;
import org.gradle.api.tasks.compile.JavaCompile;
import org.gradle.jvm.toolchain.JavaLanguageVersion;
import org.gradle.jvm.toolchain.JavaToolchainService;
import org.gradle.language.jvm.tasks.ProcessResources;

/**
 * {@code plugins { id 'dev.xavier.stein.mod' }}: um projeto Gradle que gera um .steinmod.
 *
 * <ul>
 *   <li>java com toolchain 25 (a versao do jogo), compilando com --release 25;
 *   <li>compileOnly: os jars que "stein-sdk.jar classpath &lt;projeto&gt;" imprime (o jogo com nomes legiveis, com o
 *       "access" do steinmod.json, a API e as bibliotecas do jogo) e os jars de libs/. Resolvidos so quando alguem
 *       pede — o compileJava ou a IDE ao importar; se o setup ainda nao foi feito, e feito ali (uma vez por maquina);
 *   <li>steinSetup, steinmod (no assemble, e portanto no build) e installMod.
 * </ul>
 *
 * <p>O jar comum do Java fica desligado: com os nomes legiveis ele nao roda no jogo, e ao lado do .steinmod so
 * confundiria quem procura o que por na pasta mods.
 */
public class SteinPlugin implements Plugin<Project> {

    private static final int RELEASE = 25;

    @Override
    public void apply(Project project) {
        project.getPluginManager().apply(JavaPlugin.class);
        SteinExtension stein = project.getExtensions().create("stein", SteinExtension.class);
        stein.getSdkVersion().convention(SdkTool.pluginVersion());
        stein.getSdkHome().convention(project.getLayout().dir(project.provider(SdkTool::defaultHome)));
        Object localJar = project.findProperty("stein.sdkJar");
        if (localJar != null) {
            File local = project.file(localJar);
            stein.getSdkJar().convention(project.getLayout().file(project.provider(() -> local)));
        }

        JavaPluginExtension java = project.getExtensions().getByType(JavaPluginExtension.class);
        java.getToolchain().getLanguageVersion().convention(JavaLanguageVersion.of(RELEASE));
        project.getTasks().withType(JavaCompile.class).configureEach(c -> {
            c.getOptions().getRelease().convention(RELEASE);
            c.getOptions().setEncoding("UTF-8");
        });
        JavaToolchainService toolchains = project.getExtensions().getByType(JavaToolchainService.class);
        Provider<RegularFile> javaExe = toolchains.launcherFor(java.getToolchain())
                .map(l -> l.getExecutablePath());

        File gradleHome = project.getGradle().getGradleUserHomeDir();
        boolean offline = project.getGradle().getStartParameter().isOffline();
        Provider<RegularFile> sdkJar = stein.getSdkJar().orElse(project.getLayout().file(
                stein.getSdkVersion().map(v -> SdkTool.download(gradleHome, v, offline))));

        TaskProvider<SteinSetup> setup = project.getTasks().register("steinSetup", SteinSetup.class, t -> {
            t.getSdkJar().set(sdkJar);
            t.getJavaExecutable().set(javaExe);
            t.getSdkHome().set(stein.getSdkHome());
            t.getMinecraftDir().set(stein.getMinecraftDir());
        });

        // O classpath do SDK, pedido ao proprio SDK (SdkClasspath). Lido uma vez por build: a IDE e o compileJava
        // resolvem mais de uma vez, e cada leitura seria um java a mais. Os parametros vao ja resolvidos (arquivos, e
        // nao providers): o configuration cache confere o ValueSource de novo a cada build, e ali o toolchain do
        // projeto nao existe mais.
        File projectDir = project.getProjectDir();
        ProviderFactory providers = project.getProviders();
        Callable<List<File>> once = new Callable<>() {
            private List<File> cached;

            @Override
            public synchronized List<File> call() {
                if (cached == null) {
                    RegularFile jar = sdkJar.get();
                    RegularFile javaFile = javaExe.get();
                    Directory home = stein.getSdkHome().get();
                    Directory mc = stein.getMinecraftDir().getOrNull();
                    cached = providers.of(SdkClasspath.class, s -> {
                        s.getParameters().getSdkJar().set(jar);
                        s.getParameters().getJavaExecutable().set(javaFile);
                        s.getParameters().getSdkHome().set(home);
                        s.getParameters().getMinecraftDir().set(mc);
                        s.getParameters().getProjectDir().set(projectDir);
                    }).get();
                }
                return cached;
            }
        };
        ConfigurableFileCollection cp = project.getObjects().fileCollection();
        cp.from(once);
        cp.builtBy(setup);
        project.getDependencies().add(JavaPlugin.COMPILE_ONLY_CONFIGURATION_NAME, cp);
        // Como no "java -jar stein-sdk.jar build": os jars de libs/ (a API de outro mod) so para compilar.
        project.getDependencies().add(JavaPlugin.COMPILE_ONLY_CONFIGURATION_NAME,
                project.fileTree(new File(projectDir, "libs"), t -> t.include("*.jar")));
        project.getTasks().named(JavaPlugin.COMPILE_JAVA_TASK_NAME, t -> t.dependsOn(setup));

        TaskProvider<JavaCompile> compile = project.getTasks().named(JavaPlugin.COMPILE_JAVA_TASK_NAME,
                JavaCompile.class);
        TaskProvider<ProcessResources> resources = project.getTasks().named(
                JavaPlugin.PROCESS_RESOURCES_TASK_NAME, ProcessResources.class);
        FileCollection resourceDirs = java.getSourceSets().getByName(SourceSet.MAIN_SOURCE_SET_NAME).getResources()
                .getSourceDirectories();
        String projectName = project.getName();
        Provider<String> fileName = project.provider(() -> SdkTool.modFileName(manifest(resourceDirs), projectName));

        TaskProvider<SteinPack> pack = project.getTasks().register("steinmod", SteinPack.class, t -> {
            t.getSdkJar().set(sdkJar);
            t.getJavaExecutable().set(javaExe);
            t.getSdkHome().set(stein.getSdkHome());
            t.getClassesDir().set(compile.flatMap(JavaCompile::getDestinationDirectory));
            t.getResourcesDir().set(project.getLayout().dir(resources.map(ProcessResources::getDestinationDir)));
            t.getOutputFile().set(project.getLayout().getBuildDirectory().file(fileName.map(n -> "libs/" + n)));
            t.dependsOn(JavaPlugin.CLASSES_TASK_NAME);
        });
        project.getTasks().named("assemble", t -> t.dependsOn(pack));
        project.getTasks().named(JavaPlugin.JAR_TASK_NAME, t -> t.setEnabled(false));

        project.getTasks().register("installMod", Copy.class, t -> {
            t.setGroup("stein");
            t.setDescription("Builds the mod and copies it into the mods folder of .minecraft.");
            t.from(pack.flatMap(SteinPack::getOutputFile));
            t.into(stein.getMinecraftDir().orElse(project.getLayout().dir(project.provider(
                    SdkTool::defaultMinecraft))).map(d -> d.dir("mods")).map(Directory::getAsFile));
        });
    }

    /** O steinmod.json das fontes (src/main/resources), de onde sai o nome do arquivo. */
    private static File manifest(FileCollection resourceDirs) {
        return resourceDirs.getFiles().stream().map(d -> new File(d, "steinmod.json"))
                .filter(File::isFile).findFirst().orElse(null);
    }
}
