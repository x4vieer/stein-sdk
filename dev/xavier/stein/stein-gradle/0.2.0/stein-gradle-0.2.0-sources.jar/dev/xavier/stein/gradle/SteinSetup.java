package dev.xavier.stein.gradle;

import java.util.ArrayList;
import java.util.List;

import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.tasks.Internal;
import org.gradle.api.tasks.TaskAction;

/**
 * {@code steinSetup}: "java -jar stein-sdk.jar setup" — o jogo com os nomes legiveis, na maquina de quem compila.
 * Uma vez por maquina: com o setup ja feito (o libraries.txt na pasta do SDK), a tarefa fica de fora.
 */
public abstract class SteinSetup extends SdkTask {

    /** O .minecraft de onde vem o jogo (--mc); vazio, o de sempre. */
    @Internal
    public abstract DirectoryProperty getMinecraftDir();

    public SteinSetup() {
        setGroup("stein");
        setDescription("Prepares Minecraft 1.8.9 with readable names for compiling (once per machine).");
        onlyIf("the Stein SDK is not set up yet",
                t -> !SdkTool.setupDone(((SteinSetup) t).getSdkHome().get().getAsFile()).isFile());
    }

    @TaskAction
    public void setup() {
        List<String> args = new ArrayList<>(List.of("setup"));
        if (getMinecraftDir().isPresent()) {
            args.add("--mc");
            args.add(getMinecraftDir().get().getAsFile().getAbsolutePath());
        }
        sdk(args);
    }
}
